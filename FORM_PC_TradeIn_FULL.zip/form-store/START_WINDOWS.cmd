@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install Node.js 22 or newer from nodejs.org
  pause
  exit /b 1
)
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo Created .env from .env.example. Change default passwords before external access.
)
echo Installing project dependencies...
call npm install
if errorlevel 1 (
  echo Installation failed. Check internet and Node.js version.
  pause
  exit /b 1
)
echo.
echo Open in browser: http://localhost:3001
echo PC builder: http://localhost:3001/builder.html
echo Trade-in:   http://localhost:3001/tradein.html
echo.
echo Press Ctrl+C to stop the server.
call npm start
pause
