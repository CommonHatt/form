import { test } from 'node:test';
import assert from 'node:assert/strict';
import { productGroup, evaluateBuild, cleanSelection } from '../server/pc.js';
import { estimateTradein, normalizeTradein, validMonth } from '../server/tradein.js';
const product = (id,name,extra={}) => ({id,name,category:'component',active:true,stock:5,price:100000,tags:[],specs:[],...extra});
const catalog=[
  product(22,'AMD Ryzen 7 7800X3D',{tags:['AM5']}),product(26,'ASUS ROG Strix B650E-F',{tags:['AM5'],specs:[['Память','4 слота DDR5']]}),
  product(24,'MSI RTX 5070 Ti'),product(27,'Kingston Fury Beast DDR5'),product(28,'Samsung 990 PRO 2 ТБ'),
  product(29,'Corsair RM850x 850W'),product(30,'Corsair H150i',{tags:['AM5']}),product(31,'FORM ATX Case — демо')
];
test('component classification including demo case and updated inventory',()=>{
  for (const [id,type] of [[22,'cpu'],[26,'motherboard'],[24,'gpu'],[27,'ram'],[28,'storage'],[29,'psu'],[30,'cooling'],[31,'case']]) {
    assert.equal(productGroup(catalog.find((p)=>p.id===id)),type);
  }
  assert.equal(productGroup({id:1,name:'RTX Laptop',category:'laptop'}),null);
});
test('full build calculates current catalog prices, checks socket and RAM',()=>{
  const selection={cpu:22,motherboard:26,gpu:24,ram:27,storage:28,psu:29,cooling:30,case:31};
  const result=evaluateBuild(selection,catalog);
  assert.equal(result.total,800000);
  assert.equal(result.missing,0);
  assert.equal(result.errors,0);
  assert.ok(result.alerts.some((a)=>a.severity==='ok'&&a.message.includes('AM5')));
});
test('incompatible CPU socket is reported as error',()=>{
  const result=evaluateBuild({cpu:22,motherboard:26},catalog.map((p)=>p.id===26?{...p,tags:['LGA1700'],specs:[]}:p));
  assert.ok(result.errors>0);
});
test('unknown or missing component not silently treated as compatible',()=>{
  const result=evaluateBuild({gpu:777,cpu:22},catalog);
  assert.equal(result.items.gpu,undefined);
  assert.ok(result.errors>0);
  assert.ok(result.missing>0);
  assert.deepEqual(cleanSelection({cpu:'22',gpu:'banana',storage:0}),{cpu:22});
});
const base = {deviceType:'laptop',brand:'Lenovo',model:'Legion',purchaseMonth:'2024-04',originalPrice:600000,condition:'good',working:'yes',defects:[],hasCharger:true,hasBox:true,notes:''};
const now=new Date('2026-11-11T00:00:00Z');
test('trade-in estimate provides non-binding transparent range',()=>{
  const result=estimateTradein(base,now);
  assert.ok(result.low>=0&&result.low<result.high);
  assert.ok(result.high<600000);
  assert.match(result.disclaimer,/не оферта/);
  assert.ok(result.reasoning.some((t)=>t.includes('мес.')));
});
test('trade-in defects, condition and non-working device reduce estimate',()=>{
  const clean=estimateTradein({...base,condition:'excellent'},now);
  const damaged=estimateTradein({...base,condition:'poor',working:'no',defects:['screen','liquid']},now);
  assert.ok(damaged.high<clean.low);
  assert.match(damaged.verdict,/диагностика/i);
});
test('trade-in without purchase price never fabricates monetary value',()=>{
  const result=estimateTradein({...base,originalPrice:''},now);
  assert.equal(result.low,null);
  assert.equal(result.high,null);
});
test('trade-in rejects invalid dates, prices and conditions',()=>{
  assert.equal(validMonth('2027-01',now),false);
  assert.throws(()=>normalizeTradein({...base,purchaseMonth:'2028-01'},now));
  assert.throws(()=>normalizeTradein({...base,originalPrice:-10},now));
  assert.throws(()=>normalizeTradein({...base,condition:'unknown'},now));
});
