#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js 22+ is required. Install from https://nodejs.org/' >&2
  exit 1
fi
if [ ! -f .env ]; then
  cp .env.example .env
  echo 'Created .env. Change the demo password and session secret before deployment.'
fi
npm install
echo 'Open http://localhost:3001/ (builder.html / tradein.html)'
exec npm start
