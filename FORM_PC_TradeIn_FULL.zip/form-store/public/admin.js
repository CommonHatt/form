(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
  const money = (value) => `${Number(value || 0).toLocaleString("ru-RU")} ₸`;
  let csrfToken = "";
  let currentUser = null;
  let products = [], orders = [], users = [], movements = [], tradeins = [];
  let notifyTimer;

  function notice(message, kind = "") {
    const box = $("#notice");
    box.textContent = message;
    box.className = `banner ${kind}`;
    box.classList.remove("hidden");
    clearTimeout(notifyTimer);
    notifyTimer = setTimeout(() => box.classList.add("hidden"), 6000);
  }
  async function api(url, options = {}) {
    const method = (options.method || "GET").toUpperCase();
    const headers = { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) };
    if (!["GET", "HEAD", "OPTIONS"].includes(method) && csrfToken) headers["x-csrf-token"] = csrfToken;
    const response = await fetch(url, { ...options, method, headers, credentials: "same-origin" });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Ошибка сервера (${response.status})`);
    return data;
  }
  async function refreshCsrf() {
    const result = await api("/api/auth/me");
    csrfToken = result.csrfToken || "";
    currentUser = result.user;
    return result;
  }
  const categoryNames = { monitor: "Монитор", mouse: "Мышь", keyboard: "Клавиатура", mousepad: "Коврик", laptop: "Ноутбук", headphones: "Наушники", component: "Комплектующее" };
  function showPage(name) {
    $$(".page").forEach((section) => section.classList.toggle("hidden", section.id !== `page-${name}`));
    $$("#adminNav button").forEach((button) => button.classList.toggle("active", button.dataset.page === name));
    const loaders = { overview: loadOverview, products: loadProducts, orders: loadOrders, users: loadUsers, movements: loadMovements, mail: loadMail, tradein: loadTradeins };
    loaders[name]?.().catch((error) => notice(error.message, "error"));
  }
  function setAuthorized(user) {
    currentUser = user;
    $("#loginView").classList.add("hidden");
    $("#adminView").classList.remove("hidden");
    $("#adminName").textContent = `${user.name} · администратор`;
    $("#adminName").classList.remove("hidden");
    $("#logout").classList.remove("hidden");
    showPage("overview");
  }
  function setUnauthorized(message = "") {
    currentUser = null;
    $("#adminView").classList.add("hidden");
    $("#adminName").classList.add("hidden");
    $("#logout").classList.add("hidden");
    $("#loginView").classList.remove("hidden");
    if (message) {
      $("#loginMessage").textContent = message;
      $("#loginMessage").className = "banner error";
    }
  }
  async function loadOverview() {
    const [summary, latest] = await Promise.all([api("/api/admin/overview"), api("/api/admin/orders")]);
    $("#metrics").innerHTML = [
      ["Активных товаров", summary.products], ["Единиц на складе", summary.units],
      ["Низкий остаток", summary.lowStock], ["Заказов / регистраций", `${summary.orderCount} / ${summary.userCount}`],
    ].map(([label, value]) => `<article class="metric"><span>${escapeHtml(label)}</span><strong>${Number(value || 0).toLocaleString("ru-RU")}</strong></article>`).join("");
    $("#recentOrders").innerHTML = latest.orders.slice(0, 7).map((order) => `<tr><td>${escapeHtml(order.id)}</td><td>${escapeHtml(order.accountName)}<br><span class="note">${escapeHtml(order.email)}</span></td><td>${money(order.total)}</td><td><span class="status ${order.canceled_at ? "bad" : ""}">${escapeHtml(order.status)}</span></td></tr>`).join("") || '<tr><td colspan="4" class="empty">Пока заказов нет.</td></tr>';
  }
  async function loadProducts() {
    products = (await api("/api/admin/products")).products;
    drawProducts();
  }
  function drawProducts() {
    const q = $("#productSearch").value.trim().toLocaleLowerCase("ru-RU");
    const filtered = products.filter((p) => [p.name, p.brand, p.category].join(" ").toLocaleLowerCase("ru-RU").includes(q));
    $("#productsRows").innerHTML = filtered.map((p) => {
      const low = p.stock <= 3;
      return `<tr><td><div class="product-cell"><img loading="lazy" src="${escapeHtml(p.image)}" alt=""><span><b>${escapeHtml(p.name)}</b><small>${escapeHtml(p.brand)}${p.active ? "" : " · скрыт"}</small></span></div></td><td>${escapeHtml(categoryNames[p.category] || p.category)}</td><td>${money(p.price)}</td><td><span class="status ${p.stock === 0 ? "bad" : low ? "wait" : "ok"}">${p.stock} шт.</span></td><td><div class="row-buttons"><button class="button small" data-edit-product="${p.id}">Изменить</button><button class="button small" data-stock-product="${p.id}">Остаток</button><button class="button small ${p.active ? "danger" : ""}" data-toggle-product="${p.id}">${p.active ? "Скрыть" : "Вернуть"}</button></div></td></tr>`;
    }).join("") || '<tr><td colspan="5" class="empty">Товары не найдены.</td></tr>';
  }
  async function loadOrders() {
    orders = (await api("/api/admin/orders")).orders;
    drawOrders();
  }
  const statuses = ["Оформлен (демо)", "Оплачено (демо)", "Собирается", "Отправлено", "Выдано", "Отменён"];
  function drawOrders() {
    const q = $("#orderSearch").value.trim().toLocaleLowerCase("ru-RU");
    const filtered = orders.filter((o) => [o.id, o.accountName, o.email, o.customer_name, o.phone].join(" ").toLocaleLowerCase("ru-RU").includes(q));
    $("#ordersRows").innerHTML = filtered.map((o) => {
      const items = o.items.map((i) => `${escapeHtml(i.name)} × ${i.qty}`).join("<br>");
      const select = statuses.map((s) => `<option value="${escapeHtml(s)}" ${o.status === s ? "selected" : ""}>${escapeHtml(s)}</option>`).join("");
      return `<tr><td><b>${escapeHtml(o.id)}</b><br>${escapeHtml(o.accountName || o.customer_name)}<br><span class="note">${escapeHtml(o.email)} · ${escapeHtml(o.phone)}</span><br><span class="note">${new Date(o.created_at).toLocaleString("ru-RU")}</span></td><td class="items">${items}<br><span class="note">${escapeHtml(o.city)}, ${escapeHtml(o.address)}</span></td><td>${money(o.total)}</td><td><select class="input" data-order-status="${escapeHtml(o.id)}" ${o.canceled_at ? "disabled" : ""}>${select}</select></td><td><button class="button small danger" data-cancel-order="${escapeHtml(o.id)}" ${o.canceled_at || o.status === "Выдано" ? "disabled" : ""}>Отменить</button></td></tr>`;
    }).join("") || '<tr><td colspan="5" class="empty">Заказов пока нет.</td></tr>';
  }
  async function loadUsers() {
    users = (await api("/api/admin/users")).users;
    drawUsers();
  }
  function drawUsers() {
    const q = $("#userSearch").value.trim().toLocaleLowerCase("ru-RU");
    const filtered = users.filter((u) => `${u.name} ${u.email}`.toLocaleLowerCase("ru-RU").includes(q));
    $("#usersRows").innerHTML = filtered.map((u) => `<tr><td><input class="input" data-user-name="${u.id}" value="${escapeHtml(u.name)}"><br><input class="input" style="margin-top:5px" type="email" data-user-email="${u.id}" value="${escapeHtml(u.email)}"></td><td><span class="status">${escapeHtml(u.role)}</span></td><td>${Number(u.orderCount || 0)}</td><td><span class="status ${u.isActive ? "ok" : "bad"}">${u.isActive ? "Активен" : "Отключён"}</span></td><td><div class="row-buttons"><button class="button small" data-save-user="${u.id}">Сохранить</button><button class="button small" data-toggle-user="${u.id}" ${u.id === currentUser.id ? "disabled" : ""}>${u.isActive ? "Отключить" : "Включить"}</button></div></td></tr>`).join("") || '<tr><td colspan="5" class="empty">Пользователи не найдены.</td></tr>';
  }
  async function loadMovements() {
    movements = (await api("/api/admin/movements")).movements;
    const byId = new Map(products.map((p) => [p.id, p.name]));
    $("#movementsRows").innerHTML = movements.map((m) => `<tr><td>${new Date(m.created_at).toLocaleString("ru-RU")}</td><td>${escapeHtml(m.product_name || byId.get(m.product_id) || "Товар")}</td><td>${escapeHtml(m.kind)}</td><td>${m.delta > 0 ? "+" : ""}${Number(m.delta)}</td><td>${Number(m.balance)} шт.</td><td>${escapeHtml(m.note)}</td></tr>`).join("") || '<tr><td colspan="6" class="empty">Записей пока нет.</td></tr>';
  }
  async function loadMail() {
    const data = await api("/api/admin/mail/status");
    const verified = data.verification?.ok;
    $("#mailSummary").innerHTML = `<div class="panel-head"><div><h3>Получатель: ${escapeHtml(data.recipient)}</h3><p>Отправитель: ${escapeHtml(data.sender || "не настроен")}</p></div><span class="status ${verified ? "ok" : data.configured ? "wait" : "bad"}">${verified ? "SMTP подключён" : data.configured ? "Ошибка SMTP" : "Нужна настройка"}</span></div><p class="note">${escapeHtml(data.verification?.error || "Письма о заказах, отменах и смене статуса будут идти на этот адрес.")}</p>`;
    $("#mailRows").innerHTML = data.notifications.map((n) => `<tr><td>${new Date(n.created_at).toLocaleString("ru-RU")}</td><td>${escapeHtml(n.subject)}<br><span class="note">${escapeHtml(n.order_id)}</span></td><td>${escapeHtml(n.recipient)}</td><td><span class="status ${n.status === "sent" ? "ok" : n.status === "failed" ? "bad" : "wait"}">${escapeHtml(n.status)}</span></td><td>${escapeHtml(n.error || (n.sent_at ? "Отправлено " + new Date(n.sent_at).toLocaleString("ru-RU") : "Ожидает настройки SMTP"))}</td></tr>`).join("") || '<tr><td colspan="5" class="empty">Писем пока нет.</td></tr>';
  }
  function resetProductForm() {
    $("#productForm").reset(); $("#productId").value = ""; $("#productEditorTitle").textContent = "Новый товар";
    $("#productEditor").classList.remove("hidden"); $("#productEditor").scrollIntoView({ behavior: "smooth", block: "center" });
  }
  function editProduct(product) {
    const form = $("#productForm");
    $("#productId").value = product.id; $("#productEditorTitle").textContent = `Изменить: ${product.name}`;
    for (const key of ["name", "brand", "category", "price", "stock", "badge", "image", "subtitle", "description", "warranty", "delivery"]) form.elements[key].value = product[key] ?? "";
    form.elements.tags.value = (product.tags || []).join(", ");
    $("#productEditor").classList.remove("hidden"); $("#productEditor").scrollIntoView({ behavior: "smooth", block: "center" });
  }
  async function refreshAll() {
    await Promise.all([loadOverview(), loadProducts(), loadOrders()]);
  }

  $("#loginForm").addEventListener("submit", async (event) => {
    event.preventDefault(); $("#loginSubmit").disabled = true;
    try {
      await api("/api/auth/login", { method: "POST", body: JSON.stringify({ email: $("#loginEmail").value, password: $("#loginPassword").value }) });
      const auth = await refreshCsrf();
      if (auth.user?.role !== "admin") { await api("/api/auth/logout", { method: "POST" }); csrfToken = ""; throw new Error("Этот аккаунт не имеет роли администратора."); }
      setAuthorized(auth.user);
    } catch (error) {
      $("#loginMessage").textContent = error.message;
      $("#loginMessage").className = "banner error";
      $("#loginMessage").classList.remove("hidden");
    } finally { $("#loginSubmit").disabled = false; }
  });
  $("#logout").onclick = async () => { try { await api("/api/auth/logout", { method: "POST" }); } catch {} csrfToken = ""; setUnauthorized(); };
  $("#adminNav").onclick = (event) => { const button = event.target.closest("[data-page]"); if (button) showPage(button.dataset.page); };
  document.addEventListener("click", async (event) => {
    const go = event.target.closest("[data-go]"); if (go) return showPage(go.dataset.go);
    if (event.target.closest("[data-refresh]")) return refreshAll().catch((e) => notice(e.message, "error"));
    const edit = event.target.closest("[data-edit-product]");
    if (edit) return editProduct(products.find((p) => p.id === Number(edit.dataset.editProduct)));
    if (event.target.closest("#newProduct")) return resetProductForm();
    if (event.target.closest("#cancelProductEdit")) return $("#productEditor").classList.add("hidden");
    const stock = event.target.closest("[data-stock-product]");
    if (stock) {
      const item = products.find((p) => p.id === Number(stock.dataset.stockProduct));
      const value = prompt(`Укажи точный остаток для «${item.name}»:`, String(item.stock));
      if (value === null) return;
      const amount = Number(value);
      if (!Number.isSafeInteger(amount) || amount < 0) return notice("Остаток должен быть целым числом от нуля.", "error");
      try { await api(`/api/admin/products/${item.id}`, { method: "PATCH", body: JSON.stringify({ ...item, stock: amount }) }); await loadProducts(); await loadMovements(); await loadOverview(); notice("Остаток сохранён в SQLite.", "success"); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    const toggleProduct = event.target.closest("[data-toggle-product]");
    if (toggleProduct) {
      const item = products.find((p) => p.id === Number(toggleProduct.dataset.toggleProduct));
      try { await api(`/api/admin/products/${item.id}`, { method: "PATCH", body: JSON.stringify({ ...item, active: !item.active }) }); await loadProducts(); await loadOverview(); notice("Каталог обновлён.", "success"); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    const saveUser = event.target.closest("[data-save-user]");
    if (saveUser) {
      const id = Number(saveUser.dataset.saveUser);
      try { await api(`/api/admin/users/${id}`, { method: "PATCH", body: JSON.stringify({ name: $(`[data-user-name="${id}"]`).value, email: $(`[data-user-email="${id}"]`).value }) }); await loadUsers(); notice("Данные пользователя сохранены.", "success"); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    const toggleUser = event.target.closest("[data-toggle-user]");
    if (toggleUser) {
      const u = users.find((item) => item.id === Number(toggleUser.dataset.toggleUser));
      try { await api(`/api/admin/users/${u.id}`, { method: "PATCH", body: JSON.stringify({ name: u.name, email: u.email, isActive: !u.isActive }) }); await loadUsers(); await loadOverview(); notice("Статус аккаунта обновлён.", "success"); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    const cancel = event.target.closest("[data-cancel-order]");
    if (cancel) {
      if (!confirm(`Отменить заказ ${cancel.dataset.cancelOrder}? Остатки вернутся на склад.`)) return;
      try { await api(`/api/admin/orders/${encodeURIComponent(cancel.dataset.cancelOrder)}/cancel`, { method: "POST", body: "{}" }); await loadOrders(); await loadProducts(); await loadMovements(); await loadOverview(); notice("Заказ отменён, товары возвращены на склад.", "success"); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    if (event.target.closest("#sendTestMail")) {
      try { await api("/api/admin/mail/test", { method: "POST", body: "{}" }); notice("Тестовое письмо отправлено на почту магазина.", "success"); await loadMail(); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    if (event.target.closest("#refreshMail")) loadMail().catch((e) => notice(e.message, "error"));
  });
  $("#productsRows").addEventListener("click", (event) => {});
  $("#productSearch").addEventListener("input", drawProducts);
  $("#orderSearch").addEventListener("input", drawOrders);
  $("#userSearch").addEventListener("input", drawUsers);
  $("#ordersRows").addEventListener("change", async (event) => {
    const select = event.target.closest("[data-order-status]"); if (!select) return;
    if (select.value === "Отменён") { select.value = orders.find((o) => o.id === select.dataset.orderStatus)?.status || "Оформлен (демо)"; return notice("Для отмены нажми кнопку «Отменить».", "error"); }
    try { const result = await api(`/api/admin/orders/${encodeURIComponent(select.dataset.orderStatus)}`, { method: "PATCH", body: JSON.stringify({ status: select.value }) }); await loadOrders(); await loadOverview(); notice(result.emailSent ? "Статус обновлён, письмо отправлено." : "Статус обновлён. Email пока не отправлен — проверь настройки почты.", result.emailSent ? "success" : ""); }
    catch (e) { notice(e.message, "error"); }
  });
  $("#productForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget; const data = Object.fromEntries(new FormData(form));
    data.price = Number(data.price); data.stock = Number(data.stock); data.tags = data.tags.split(",").map((x) => x.trim()).filter(Boolean);
    const id = $("#productId").value;
    try { await api(id ? `/api/admin/products/${id}` : "/api/admin/products", { method: id ? "PATCH" : "POST", body: JSON.stringify(data) }); $("#productEditor").classList.add("hidden"); await loadProducts(); await loadOverview(); await loadMovements(); notice(id ? "Товар обновлён." : "Товар добавлен в SQLite.", "success"); }
    catch (e) { notice(e.message, "error"); }
  });
  const tradeinStatus = {new:"Новая",in_review:"На проверке",offer_sent:"Предложение готово",accepted:"Согласовано",rejected:"Отклонено"};
  const defectNames = {scratches:"Царапины",dents:"Вмятины",screen:"Экран",battery:"Аккумулятор",ports:"Разъёмы",overheating:"Перегрев",liquid:"Попадание жидкости",repairs:"Ремонт",other:"Другое"};
  async function loadTradeins() {
    tradeins = (await api("/api/admin/tradein")).requests;
    drawTradeins();
  }
  function drawTradeins() {
    const query = $("#tradeinSearch").value.trim().toLowerCase();
    const rows = tradeins.filter((r) => [r.customerName,r.email,r.phone,r.brand,r.model].join(" ").toLowerCase().includes(query));
    $("#tradeinRows").innerHTML = rows.map((r) => `<tr data-tradein="${r.id}">
      <td><b class="trade-device">#${r.id} · ${escapeHtml(r.brand)} ${escapeHtml(r.model)}</b><div class="trade-meta">${escapeHtml(r.customerName)}<br>${escapeHtml(r.email)}<br>${escapeHtml(r.phone)}<br>${escapeHtml(r.createdAt)}<br>Покупка: ${escapeHtml(r.purchaseMonth)}</div></td>
      <td><span class="trade-status">${escapeHtml(tradeinStatus[r.status] || r.status)}</span><p class="trade-meta">Состояние: ${escapeHtml(r.condition)} / ${escapeHtml(r.working)}<br>Недостатки: ${escapeHtml((r.defects||[]).map(d => defectNames[d]||d).join(', ')||'Не указаны')}<br>${escapeHtml(r.notes||'')}</p><div class="trade-gallery">${(r.photos||[]).map((p) => `<a href="${p.url}" target="_blank" rel="noopener"><img loading="lazy" src="${p.url}" alt="Фото техники клиента"></a>`).join("")}</div></td>
      <td><b>${r.estimateLow==null?"По результатам осмотра":money(r.estimateLow)+" – "+money(r.estimateHigh)}</b><p class="trade-meta">${escapeHtml(r.verdict)}</p></td>
      <td><div class="trade-form-controls"><select data-tradein-status="${r.id}" aria-label="Статус Trade-in #${r.id}">${Object.entries(tradeinStatus).map(([key,value])=>`<option value="${key}" ${r.status===key?"selected":""}>${value}</option>`).join("")}</select><input data-tradein-offer="${r.id}" type="number" min="0" max="100000000" step="1" value="${r.adminOffer??""}" placeholder="Предложение, ₸" aria-label="Предложение менеджера"><textarea data-tradein-note="${r.id}" maxlength="2000" placeholder="Заметка менеджера" aria-label="Комментарий менеджера">${escapeHtml(r.managerNote||"")}</textarea><button class="button small dark" data-tradein-save="${r.id}">Сохранить решение</button><button class="button small danger" data-tradein-delete="${r.id}">Удалить заявку</button></div></td>
    </tr>`).join("") || '<tr><td colspan="4" class="empty">Заявок не найдено.</td></tr>';
  }
  $("#tradeinSearch").addEventListener("input", drawTradeins);
  $("#refreshTradeins").addEventListener("click", () => loadTradeins().catch((e) => notice(e.message,"error")));
  $("#tradeinRows").addEventListener("click", async(e) => {
    const save=e.target.closest("[data-tradein-save]"), del=e.target.closest("[data-tradein-delete]");
    if(save){
      const id=Number(save.dataset.tradeinSave);
      const status=$(`[data-tradein-status="${id}"]`).value;
      const adminOffer=$(`[data-tradein-offer="${id}"]`).value;
      const managerNote=$(`[data-tradein-note="${id}"]`).value;
      save.disabled=true;
      try{await api(`/api/admin/tradein/${id}`,{method:"PATCH",body:JSON.stringify({status,adminOffer,managerNote})});await loadTradeins();notice("Решение по Trade-in сохранено.","success");}
      catch(err){notice(err.message,"error");save.disabled=false;}
    }
    if(del){
      const id=Number(del.dataset.tradeinDelete);
      if(!confirm(`Удалить заявку #${id} и все её фотографии?`))return;
      del.disabled=true;
      try{await api(`/api/admin/tradein/${id}`,{method:"DELETE"});await loadTradeins();notice("Заявка и фотографии удалены.","success");}
      catch(err){notice(err.message,"error");del.disabled=false;}
    }
  });

  async function boot() {
    try {
      const auth = await refreshCsrf();
      if (auth.user?.role === "admin") setAuthorized(auth.user);
      else if (auth.user) setUnauthorized("Войдите под аккаунтом администратора. Сейчас активен аккаунт покупателя.");
    } catch { setUnauthorized("Не удалось подключиться к серверу."); }
  }
  boot();
})();
