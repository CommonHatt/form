import { q, money, escapeHtml as esc, api, initialize, currentUser, notify, setBusy } from "./feature-common.js";

const selectionKey = "form-pc-builder-v1";
const labels = {cpu:"Процессор",motherboard:"Материнская плата",gpu:"Видеокарта",ram:"Оперативная память",storage:"Накопитель",psu:"Блок питания",cooling:"Охлаждение",case:"Корпус"};
const short = {cpu:"CPU",motherboard:"Плата",gpu:"GPU",ram:"ОЗУ",storage:"SSD",psu:"БП",cooling:"Охлаждение",case:"Корпус"};
let catalog = { groups: [], components: [] }, selection = {}, checked = null, requestSerial = 0;
const byId = () => new Map(catalog.components.map((p) => [p.id, p]));
function loadLocal() { try { const o = JSON.parse(localStorage.getItem(selectionKey) || "{}"); return o && typeof o === "object" ? o : {}; } catch { return {}; } }
function saveLocal() { try { localStorage.setItem(selectionKey, JSON.stringify(selection)); } catch {} }
function renderGroups() {
  q("#buildGroups").innerHTML = catalog.groups.map((group, index) => {
    const options = catalog.components.filter((p) => p.group === group.key);
    const empty = `<p class="option-empty">Для раздела «${esc(group.name)}» пока нет товаров. Администратор может добавить их в разделе «Комплектующие».</p>`;
    return `<section class="component-section fade-in" id="group-${group.key}">
      <div class="component-heading"><span class="component-number">${String(index+1).padStart(2,"0")}</span><div class="component-name"><h2>${esc(group.name)}</h2><p>${group.required?"Обязательный компонент":"Необязательный компонент"}</p></div><span class="component-count">${options.length} в каталоге</span></div>
      <div class="component-options">${options.length ? options.map((p) => {
        const selected = Number(selection[group.key]) === p.id;
        return `<button type="button" class="component-option ${selected?"selected":""}" data-group="${group.key}" data-product="${p.id}" aria-pressed="${selected}" ${p.stock < 1 ? "disabled" : ""}>
          <img src="${esc(p.image)}" alt="" loading="lazy"><span class="component-option-info"><strong>${esc(p.name)}</strong><small>${esc((p.tags || []).slice(0,3).join(" · ") || p.subtitle)}</small></span><span class="component-option-price"><b>${money(p.price)}</b><i class="${p.stock?"":"out"}">${p.stock?"В наличии":"Нет в наличии"}</i></span>
          </button>`; }).join("") : empty}</div>
      </section>`;
  }).join("");
}
function renderSummary(result) {
  checked = result;
  const chosen = Object.values(result.items || {});
  const required = catalog.groups.filter((g)=>g.required);
  q("#buildProgress").textContent = `${chosen.length} из ${required.length} компонентов выбрано · ${result.errors ? "Есть ошибки" : "Проверка активна"}`;
  q("#buildTotal").textContent = money(result.total);
  q("#buildVerdict").textContent = result.verdict;
  q("#buildSummary").innerHTML = catalog.groups.map((g) => `<div class="summary-item"><span>${esc(short[g.key])}</span><b title="${esc(result.items?.[g.key]?.name||"Не выбрано")}">${esc(result.items?.[g.key]?.name || "—")}</b></div>`).join("");
  q("#buildChecks").innerHTML = (result.alerts?.length ? result.alerts.map((a) => `<div class="check-row ${esc(a.severity)}"><span class="check-icon"></span><span>${esc(a.message)}</span></div>`).join("") : '<p class="hint-line">Пока нет проверок.</p>');
  q("#addBuildToCart").disabled = !chosen.length || !!result.errors;
  q("#saveBuild").disabled = !chosen.length || !!result.errors;
}
async function check() {
  const mySerial = ++requestSerial;
  saveLocal(); renderGroups();
  const params = new URLSearchParams();
  for (const [group,id] of Object.entries(selection)) if (id) params.set(group,String(id));
  try {
    const result = await api("/api/pc/check?" + params.toString());
    if (mySerial === requestSerial) renderSummary(result);
  } catch(e) { if(mySerial===requestSerial) notify(e.message,"error"); }
}
async function loadSaved() {
  if (!currentUser()) { q("#savedBuilds").innerHTML = '<p class="muted-text">Чтобы сохранять сборки, <a href="/">войдите в аккаунт в магазине</a>. Сам конфигуратор доступен без входа.</p>'; return; }
  try {
    const data = await api("/api/pc/builds");
    q("#savedBuilds").innerHTML = data.builds.length ? data.builds.map((row) => `<article class="saved-card"><span class="feature-kicker">СБОРКА #${row.id}</span><h3>${esc(row.name)}</h3><p>${Object.keys(row.selection).length} деталей · ${new Date(row.updatedAt + "Z").toLocaleDateString("ru-RU")}</p><div class="saved-card-actions"><button class="outline-button" data-load="${row.id}">Загрузить</button><button class="ghost-button" data-delete="${row.id}">Удалить</button></div></article>`).join("") : '<p class="muted-text">Пока нет сохранённых сборок. Выберите компоненты и нажмите «Сохранить в аккаунте».</p>';
    q("#savedBuilds").dataset.rows = JSON.stringify(data.builds);
  } catch(e) { q("#savedBuilds").textContent = e.message; }
}
q("#buildGroups").addEventListener("click", (event) => {
  const button = event.target.closest("button[data-group][data-product]");
  if (!button || button.disabled) return;
  const group = button.dataset.group, id = Number(button.dataset.product);
  if (selection[group] === id) delete selection[group]; else selection[group] = id;
  void check();
});
q("#applyPreset").addEventListener("click", () => {
  const preset = {cpu:22,motherboard:26,gpu:24,ram:27,storage:28,psu:29,cooling:30,case:31};
  selection = {};
  const m = byId();
  for (const [key,id] of Object.entries(preset)) if(m.get(id)?.stock) selection[key]=id;
  void check();
  notify("Пример сборки загружен. Вы можете заменить любую деталь.");
});
q("#clearBuild").addEventListener("click", () => { selection={};void check(); });
q("#saveBuild").addEventListener("click", async (e) => {
  if(!currentUser()) return notify("Чтобы сохранить сборку, войдите в аккаунт на главной странице.","error");
  const button = e.currentTarget;
  setBusy(button,true);
  try {
    await api("/api/pc/builds", { method:"POST", body:JSON.stringify({ name:q("#buildName").value.trim(), selection }) });
    notify("Сборка сохранена в вашем аккаунте.","success"); await loadSaved();
  } catch(err) { notify(err.message,"error"); } finally { setBusy(button,false); }
});
q("#savedBuilds").addEventListener("click", async(e) => {
  const load = e.target.closest("[data-load]"), del = e.target.closest("[data-delete]");
  let rows=[]; try {rows=JSON.parse(q("#savedBuilds").dataset.rows||"[]");}catch{}
  if(load) {
    const row=rows.find((x)=>x.id===Number(load.dataset.load)); if(!row) return;
    selection = {...row.selection}; q("#buildName").value=row.name; await check();
    q("#buildProgress").scrollIntoView({behavior:"smooth",block:"center"});notify("Сохранённая сборка открыта.");
  }
  if(del){ try{await api(`/api/pc/builds/${Number(del.dataset.delete)}`,{method:"DELETE"});await loadSaved();notify("Сборка удалена.");}catch(err){notify(err.message,"error");} }
});
q("#addBuildToCart").addEventListener("click",async () => {
  if(!checked||checked.errors) return notify("Исправьте найденные ошибки совместимости и наличия.","error");
  const products = Object.values(checked.items||{});
  if(!products.length) return notify("Выберите хотя бы одну деталь.","error");
  if(checked.missing) notify("Внимание: в сборке ещё не выбраны некоторые компоненты.");
  const key = `form-state-v1-${currentUser()?.id ?? "guest"}`;
  let state = {};
  try { state=JSON.parse(localStorage.getItem(key)||"{}"); } catch {}
  if(!state || typeof state!=="object") state={};
  if(!Array.isArray(state.cart)) state.cart=[];
  for(const p of products) {
    if(p.stock<1) continue;
    const item=state.cart.find((x)=>x.id===p.id);
    if(item) item.qty=Math.min(Number(p.stock), Math.min(99,Number(item.qty||0)+1));
    else state.cart.push({id:p.id,qty:1});
  }
  try { localStorage.setItem(key,JSON.stringify(state));notify("Комплектующие добавлены в корзину. Откройте магазин, чтобы оформить демо-заказ.","success"); }
  catch { notify("Не получилось сохранить корзину в браузере.","error"); }
});
(async()=>{
  await initialize();
  selection=loadLocal();
  try { catalog=await api("/api/pc/catalog"); await check(); await loadSaved(); }
  catch(err){q("#buildGroups").innerHTML=`<p class="option-empty">Ошибка загрузки каталога: ${esc(err.message)}. Запустите сервер через npm run dev.</p>`;}
})();
