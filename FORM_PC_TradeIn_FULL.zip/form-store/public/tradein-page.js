import { q, money, escapeHtml as esc, api, initialize, currentUser, notify, setBusy } from "./feature-common.js";
const form = q("#tradeForm"), input = q("#tradePhotos"), photos=[];
const statusName={new:"Новая",in_review:"На проверке",offer_sent:"Предложение готово",accepted:"Согласовано",rejected:"Отказано"};
function fields() {
  const fd=new FormData(form);
  return {
    deviceType:fd.get("deviceType"),brand:fd.get("brand")?.trim(),model:fd.get("model")?.trim(),
    purchaseMonth:fd.get("purchaseMonth"),originalPrice:fd.get("originalPrice")||"",
    condition:fd.get("condition"),working:fd.get("working"),defects:fd.getAll("defects"),
    notes:fd.get("notes"),hasCharger:fd.has("hasCharger"),hasBox:fd.has("hasBox"),
    customerName:fd.get("customerName"),phone:fd.get("phone"),email:fd.get("email")
  };
}
function showEstimate(result) {
  q("#estimateAmount").textContent = result.low === null ? "После осмотра" : `${money(result.low)} — ${money(result.high)}`;
  q("#estimateVerdict").textContent=result.verdict;
  q("#estimateFactors").innerHTML=result.reasoning.map((t)=>`<div>${esc(t)}</div>`).join("") + `<p class="legal-note">${esc(result.disclaimer)}</p>`;
}
async function estimate() {
  const result=await api("/api/tradein/estimate",{method:"POST",body:JSON.stringify(fields())});
  showEstimate(result);return result;
}
q("#estimateButton").addEventListener("click",async(e)=>{
  setBusy(e.currentTarget,true,"Расчёт…");
  try { await estimate(); notify("Предварительная оценка рассчитана.","success"); }
  catch(err){notify(err.message,"error");}
  finally{setBusy(q("#estimateButton"),false);}
});
function renderPreviews() {
  q("#photoPreviews").innerHTML=photos.map((p,i)=>`<div class="preview-item"><img src="${p.preview}" alt="Фото устройства ${i+1}"><button type="button" data-remove-photo="${i}" aria-label="Убрать фотографию">×</button></div>`).join("");
}
input.addEventListener("change",(event)=>{
  for(const f of event.target.files){
    if(photos.length>=4){notify("Можно добавить максимум четыре фотографии.","error");break;}
    if(!["image/jpeg","image/png","image/webp"].includes(f.type)){notify("Разрешены JPG, PNG и WebP.","error");continue;}
    if(f.size>15_000_000){notify("Исходное фото должно быть меньше 15 МБ.","error");continue;}
    photos.push({file:f,preview:URL.createObjectURL(f)});
  }
  renderPreviews();event.target.value="";
});
q("#photoPreviews").addEventListener("click",(event)=>{
  const button=event.target.closest("[data-remove-photo]");if(!button)return;
  const [item]=photos.splice(Number(button.dataset.removePhoto),1);if(item)URL.revokeObjectURL(item.preview);renderPreviews();
});
async function encodePhoto(file){
  const src=URL.createObjectURL(file), image=new Image();
  try{
    await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error("Фото не удалось открыть."));image.src=src;});
    const max=1400,scale=Math.min(1,max/Math.max(image.naturalWidth,image.naturalHeight));
    const canvas=document.createElement("canvas");canvas.width=Math.round(image.naturalWidth*scale);canvas.height=Math.round(image.naturalHeight*scale);
    if(!canvas.width||!canvas.height)throw new Error("Некорректный размер фотографии.");
    const ctx=canvas.getContext("2d");ctx.fillStyle="#fff";ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);
    let quality=.82,data="";
    do{data=canvas.toDataURL("image/jpeg",quality);quality-=.12;}while(data.length>2_500_000&&quality>.25);
    if(data.length>2_600_000)throw new Error("Фотография слишком большая даже после сжатия.");
    return data;
  }finally{URL.revokeObjectURL(src);}
}
async function loadMine(){
  if(!currentUser())return;
  try{
    const data=await api("/api/tradein/mine");
    q("#myTradeins").innerHTML=data.requests.length?data.requests.map((r)=>`<article class="request-card"><span class="feature-kicker">ЗАЯВКА #${r.id}</span><h3>${esc(r.brand)} ${esc(r.model)}</h3><span class="status-chip">${esc(statusName[r.status]||r.status)}</span><p>Дата: ${esc(r.createdAt)}<br>Диапазон: ${r.estimateLow===null?"По осмотру":money(r.estimateLow)+" — "+money(r.estimateHigh)}</p>${r.adminOffer!==null?`<p><b>Предложение менеджера: ${money(r.adminOffer)}</b></p>`:""}${r.managerNote?`<p>Комментарий: ${esc(r.managerNote)}</p>`:""}<div class="request-photos">${r.photos.map((p)=>`<a href="${p.url}" target="_blank" rel="noopener"><img src="${p.url}" alt="Фото из заявки"></a>`).join("")}</div></article>`).join("") : '<p class="muted-text">Вы ещё не отправляли заявки на Trade-in.</p>';
  }catch(err){q("#myTradeins").textContent=err.message;}
}
form.addEventListener("submit",async(event)=>{
  event.preventDefault();
  if(!form.reportValidity())return;
  if(!q("#tradeConsent").checked)return notify("Подтвердите согласие на обработку данных.","error");
  if(!photos.length)return notify("Добавьте хотя бы одну фотографию устройства.","error");
  const button=q("#submitTrade");setBusy(button,true,"Подготовка фотографий…");
  try{
    const data=fields();data.photos=await Promise.all(photos.map((p)=>encodePhoto(p.file)));
    const result=await api("/api/tradein/requests",{method:"POST",body:JSON.stringify(data)});
    showEstimate(result.estimate);
    notify(`Заявка #${result.id} принята. Это не подтверждение выкупа.`,"success");
    q("#estimateAmount").scrollIntoView({behavior:"smooth",block:"center"});
    await loadMine();
  }catch(err){notify(err.message,"error");}
  finally{setBusy(button,false);}
});
(async()=>{
  const user=await initialize();
  const d=new Date();q("#purchaseMonth").max=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;
  if(user){form.elements.customerName.value=user.name||"";form.elements.email.value=user.email||"";}
  await loadMine();
})();
