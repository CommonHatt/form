export const q = (selector, root = document) => root.querySelector(selector);
export const qa = (selector, root = document) => [...root.querySelectorAll(selector)];
export const money = (number) => `${Number(number ?? 0).toLocaleString("ru-RU")} ₸`;
export const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
let csrfToken = "";
let me = null;
export async function initialize() {
  try { const saved = localStorage.getItem("form-shop-theme"); if (saved === "dark") document.documentElement.dataset.theme = "dark"; } catch {}
  try {
    const data = await api("/api/auth/me");
    csrfToken = data.csrfToken || "";
    me = data.user || null;
    q("#loginBadge").textContent = me ? me.name : "Гость";
  } catch { q("#loginBadge").textContent = "Нет соединения"; }
  q("#featureTheme")?.addEventListener("click", () => {
    const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem("form-shop-theme", next); } catch {}
  });
  return me;
}
export const currentUser = () => me;
export async function api(url, options = {}) {
  const method = (options.method || "GET").toUpperCase();
  const headers = { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) };
  if (!["GET", "HEAD", "OPTIONS"].includes(method) && csrfToken) headers["x-csrf-token"] = csrfToken;
  const response = await fetch(url, { ...options, method, headers, credentials: "same-origin" });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Ошибка сервера ${response.status}`);
  return data;
}
let toastId;
export function notify(message, type = "info") {
  const element = q("#featureToast");
  element.textContent = message;
  element.className = `feature-toast show ${type}`;
  clearTimeout(toastId);
  toastId = setTimeout(() => element.classList.remove("show"), 4300);
}
export function setBusy(button, busy, label) {
  if (!button) return;
  if (!button.dataset.originalLabel) button.dataset.originalLabel = button.textContent;
  button.disabled = busy;
  button.textContent = busy ? (label || "Обработка…") : button.dataset.originalLabel;
}
