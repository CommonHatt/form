import "dotenv/config";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import session from "express-session";
import rateLimit from "express-rate-limit";
import { OAuth2Client } from "google-auth-library";
import { createRemoteJWKSet, importPKCS8, jwtVerify, SignJWT } from "jose";
import bcrypt from "bcryptjs";
import { db, productFromRow, publicUser } from "./db.js";
import { mailConfiguration, sendOrderNotification, sendTestEmail, verifyMailConfiguration } from "./mailer.js";
import { installFeatures } from "./features.js";

const app = express();
const port = Number(process.env.PORT || 3001);
const clientUrl = process.env.CLIENT_URL || "http://localhost:3001";
const baseUrl = process.env.BASE_URL || "http://localhost:" + port;
const here = path.dirname(fileURLToPath(import.meta.url));

class SQLiteSessionStore extends session.Store {
  constructor() {
    super();
    this.readSession = db.prepare("SELECT session_json,expires_at FROM sessions WHERE sid=?");
    this.writeSession = db.prepare("INSERT INTO sessions (sid,session_json,expires_at) VALUES (?,?,?) ON CONFLICT(sid) DO UPDATE SET session_json=excluded.session_json,expires_at=excluded.expires_at");
    this.removeSession = db.prepare("DELETE FROM sessions WHERE sid=?");
  }
  get(sid, callback) {
    try {
      const row = this.readSession.get(sid);
      if (!row || row.expires_at <= Date.now()) {
        if (row) this.removeSession.run(sid);
        return callback(null, null);
      }
      callback(null, JSON.parse(row.session_json));
    } catch (error) { callback(error); }
  }
  set(sid, sessionData, callback = () => {}) {
    try {
      const expiry = sessionData.cookie && sessionData.cookie.expires
        ? new Date(sessionData.cookie.expires).getTime()
        : Date.now() + Number(sessionData.cookie && sessionData.cookie.maxAge || 86400000);
      this.writeSession.run(sid, JSON.stringify(sessionData), expiry);
      callback(null);
    } catch (error) { callback(error); }
  }
  touch(sid, sessionData, callback = () => {}) { this.set(sid, sessionData, callback); }
  destroy(sid, callback = () => {}) {
    try { this.removeSession.run(sid); callback(null); }
    catch (error) { callback(error); }
  }
}

app.disable("x-powered-by");
if (process.env.NODE_ENV === "production") app.set("trust proxy", 1);
app.use(express.json({ limit: "12mb" }));
app.use(express.urlencoded({ extended: false, limit: "100kb" }));
app.use(session({
  store: new SQLiteSessionStore(),
  name: "form.sid",
  secret: process.env.SESSION_SECRET || "local-demo-secret-change-before-deploy",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: baseUrl.startsWith("https://"), maxAge: 7 * 24 * 60 * 60 * 1000 }
}));



const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 40, standardHeaders: "draft-8", legacyHeaders: false });
const oauthClient = process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
  ? new OAuth2Client(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET, baseUrl + "/api/auth/google/callback")
  : null;
const appleConfigured = Boolean(process.env.APPLE_CLIENT_ID && process.env.APPLE_TEAM_ID && process.env.APPLE_KEY_ID && process.env.APPLE_PRIVATE_KEY);

function cleanText(value, max = 180) { return typeof value === "string" ? value.trim().slice(0, max) : ""; }
function emailValue(value) { return cleanText(value, 254).toLowerCase(); }
function apiError(res, status, message) { return res.status(status).json({ error: message }); }
function userFromRequest(req) {
  if (!req.session.userId) return null;
  return db.prepare("SELECT * FROM users WHERE id = ? AND is_active = 1").get(req.session.userId) || null;
}
function requireAuth(req, res, next) {
  const user = userFromRequest(req);
  if (!user) return apiError(res, 401, "Войдите в аккаунт.");
  req.user = user;
  next();
}
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== "admin") return apiError(res, 403, "Нужен доступ администратора.");
  next();
}
function requireCsrf(req, res, next) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  if (req.path.startsWith("/auth/login") || req.path.startsWith("/auth/register") || req.path.startsWith("/auth/google/callback") || req.path.startsWith("/auth/apple/callback")) return next();
  if (!req.session.csrfToken || req.get("x-csrf-token") !== req.session.csrfToken) return apiError(res, 403, "Обновите страницу и повторите действие.");
  next();
}
app.use("/api", requireCsrf);

function saveLogin(req, user) {
  return new Promise((resolve, reject) => {
    req.session.regenerate((error) => {
      if (error) return reject(error);
      req.session.userId = user.id;
      req.session.csrfToken = crypto.randomBytes(24).toString("base64url");
      req.session.save((saveError) => saveError ? reject(saveError) : resolve());
    });
  });
}
function saveLogout(req) { return new Promise((resolve) => req.session.destroy(() => resolve())); }
function publicProduct(row) {
  const item = productFromRow(row);
  if (item) item.active = Boolean(row.active);
  return item;
}
function productBody(body, current = null) {
  const categories = ["monitor", "mouse", "keyboard", "mousepad", "laptop", "headphones", "component"];
  const name = cleanText(body.name, 120);
  const brand = cleanText(body.brand, 60);
  const category = cleanText(body.category, 30);
  const price = Number(body.price);
  const stock = body.stock === undefined && current ? current.stock : Number(body.stock);
  if (!name || !brand || !categories.includes(category)) throw new Error("Укажите название, бренд и категорию.");
  if (!Number.isSafeInteger(price) || price < 0) throw new Error("Цена должна быть целым числом от нуля.");
  if (!Number.isSafeInteger(stock) || stock < 0 || stock > 999999) throw new Error("Остаток должен быть числом от 0 до 999999.");
  const image = cleanText(body.image, 3_500_000) || (current && current.image) || "";
  const tags = Array.isArray(body.tags) ? body.tags.slice(0, 12).map((x) => cleanText(x, 40)).filter(Boolean) : (current ? current.tags : []);
  const specs = Array.isArray(body.specs) ? body.specs.slice(0, 20).map((row) => [cleanText(row[0], 60), cleanText(row[1], 120)]) : (current ? current.specs : []);
  return {
    name, category, subtitle: cleanText(body.subtitle, 150), brand, price,
    badge: cleanText(body.badge, 50) || (category === "laptop" ? "Ноутбуки" : category === "audio" ? "Звук" : "Аксессуары"),
    image, tags, description: cleanText(body.description, 1400), source: cleanText(body.source, 500),
    fresh: body.fresh === undefined ? Boolean(current && current.fresh) : Boolean(body.fresh),
    specs, inTheBox: cleanText(body.inTheBox, 400), warranty: cleanText(body.warranty, 100),
    delivery: cleanText(body.delivery, 100), stock
  };
}
function insertMovement(productId, productName, kind, delta, balance, note = "") {
  db.prepare("INSERT INTO stock_movements (product_id,product_name,kind,delta,balance,note) VALUES (?,?,?,?,?,?)")
    .run(productId, productName, kind, delta, balance, cleanText(note, 240));
}
function orderWithItems(order) {
  const items = db.prepare("SELECT product_id AS id,name_snapshot AS name,quantity AS qty,unit_price AS price FROM order_items WHERE order_id = ?").all(order.id);
  return { ...order, total: Number(order.total), subtotal: Number(order.subtotal), discount: Number(order.discount), items };
}
function createOAuthState(provider) {
  db.prepare("DELETE FROM oauth_states WHERE expires_at < ?").run(Date.now());
  const state = crypto.randomBytes(32).toString("base64url");
  const nonce = crypto.randomBytes(32).toString("base64url");
  db.prepare("INSERT INTO oauth_states (state,provider,nonce,expires_at) VALUES (?,?,?,?)").run(state, provider, nonce, Date.now() + 600000);
  return { state, nonce };
}
function consumeOAuthState(state, provider) {
  if (!state) return null;
  const row = db.prepare("SELECT * FROM oauth_states WHERE state = ? AND provider = ? AND expires_at > ?").get(state, provider, Date.now());
  if (row) db.prepare("DELETE FROM oauth_states WHERE state = ?").run(state);
  return row || null;
}
function ensureOAuthAccount(provider, providerId, email, name) {
  const normalized = emailValue(email);
  if (!normalized || !providerId) throw new Error("Провайдер не вернул подтверждённый email.");
  let user = db.prepare("SELECT * FROM users WHERE provider = ? AND provider_id = ?").get(provider, providerId);
  if (user) return user;
  user = db.prepare("SELECT * FROM users WHERE email = ?").get(normalized);
  if (user) {
    if (user.role !== "admin" && !user.provider_id) {
      db.prepare("UPDATE users SET provider = ?, provider_id = ?, name = CASE WHEN name = '' THEN ? ELSE name END WHERE id = ?")
        .run(provider, providerId, cleanText(name, 100) || normalized.split("@")[0], user.id);
    }
    return db.prepare("SELECT * FROM users WHERE id = ?").get(user.id);
  }
  const info = db.prepare("INSERT INTO users (name,email,provider,provider_id,role) VALUES (?,?,?,?,'customer')")
    .run(cleanText(name, 100) || normalized.split("@")[0], normalized, provider, providerId);
  return db.prepare("SELECT * FROM users WHERE id = ?").get(info.lastInsertRowid);
}
function oauthFailure(res, code) { return res.redirect(clientUrl + "/?oauthError=" + encodeURIComponent(code)); }

app.get("/api/health", (_req, res) => res.json({ ok: true, database: "sqlite" }));
app.get("/api/auth/providers", (_req, res) => res.json({ google: Boolean(oauthClient), apple: appleConfigured }));
app.get("/api/auth/me", (req, res) => {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(24).toString("base64url");
  const user = userFromRequest(req);
  res.json({ user: user ? publicUser(user) : null, csrfToken: req.session.csrfToken });
});
app.post("/api/auth/register", authLimiter, async (req, res) => {
  const name = cleanText(req.body.name, 100), email = emailValue(req.body.email);
  const password = typeof req.body.password === "string" ? req.body.password : "";
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return apiError(res, 400, "Введите имя и корректный email.");
  if (password.length < 8 || password.length > 128) return apiError(res, 400, "Пароль должен быть от 8 до 128 символов.");
  try {
    const info = db.prepare("INSERT INTO users (name,email,password_hash) VALUES (?,?,?)").run(name, email, await bcrypt.hash(password, 12));
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(info.lastInsertRowid);
    await saveLogin(req, user);
    res.status(201).json({ user: publicUser(user) });
  } catch (error) {
    if (String(error.code).includes("SQLITE_CONSTRAINT")) return apiError(res, 409, "Этот email уже зарегистрирован.");
    console.error(error); apiError(res, 500, "Не удалось создать аккаунт.");
  }
});
app.post("/api/auth/login", authLimiter, async (req, res) => {
  const email = emailValue(req.body.email), password = typeof req.body.password === "string" ? req.body.password : "";
  const user = db.prepare("SELECT * FROM users WHERE email = ? AND is_active = 1").get(email);
  if (!user || !user.password_hash || !(await bcrypt.compare(password, user.password_hash))) return apiError(res, 401, "Неверный email или пароль.");
  await saveLogin(req, user);
  res.json({ user: publicUser(user) });
});
app.post("/api/auth/logout", requireAuth, async (req, res) => {
  await saveLogout(req); res.clearCookie("form.sid"); res.json({ ok: true });
});

app.get("/api/auth/google", (_req, res) => {
  if (!oauthClient) return oauthFailure(res, "google-not-configured");
  const { state, nonce } = createOAuthState("google");
  res.redirect(oauthClient.generateAuthUrl({ scope: ["openid", "email", "profile"], state, nonce, prompt: "select_account" }));
});
app.get("/api/auth/google/callback", async (req, res) => {
  try {
    if (req.query.error) return oauthFailure(res, "google-cancelled");
    const saved = consumeOAuthState(cleanText(req.query.state, 160), "google");
    if (!saved || !req.query.code) return oauthFailure(res, "oauth-state");
    const tokens = await oauthClient.getToken(cleanText(req.query.code, 2000));
    const ticket = await oauthClient.verifyIdToken({ idToken: tokens.tokens.id_token, audience: process.env.GOOGLE_CLIENT_ID });
    const payload = ticket.getPayload();
    if (!payload || !payload.email_verified || payload.nonce !== saved.nonce) return oauthFailure(res, "google-verification");
    const user = ensureOAuthAccount("google", payload.sub, payload.email, payload.name);
    if (!user.is_active) return oauthFailure(res, "account-disabled");
    await saveLogin(req, user); res.redirect(clientUrl + "/");
  } catch (error) { console.error("Google OAuth:", error.message); oauthFailure(res, "google-failed"); }
});

async function appleClientSecret() {
  const keyText = (process.env.APPLE_PRIVATE_KEY || "").replace(/\\n/g, "\n");
  const key = await importPKCS8(keyText, "ES256");
  return new SignJWT({})
    .setProtectedHeader({ alg: "ES256", kid: process.env.APPLE_KEY_ID })
    .setIssuer(process.env.APPLE_TEAM_ID)
    .setSubject(process.env.APPLE_CLIENT_ID)
    .setAudience("https://appleid.apple.com")
    .setIssuedAt()
    .setExpirationTime("5m")
    .sign(key);
}
const appleJwks = createRemoteJWKSet(new URL("https://appleid.apple.com/auth/keys"));
app.get("/api/auth/apple", (_req, res) => {
  if (!appleConfigured) return oauthFailure(res, "apple-not-configured");
  const { state, nonce } = createOAuthState("apple");
  const query = new URLSearchParams({
    client_id: process.env.APPLE_CLIENT_ID, redirect_uri: baseUrl + "/api/auth/apple/callback",
    response_type: "code", response_mode: "form_post", scope: "name email", state, nonce
  });
  res.redirect("https://appleid.apple.com/auth/authorize?" + query.toString());
});
app.post("/api/auth/apple/callback", async (req, res) => {
  try {
    if (req.body.error) return oauthFailure(res, "apple-cancelled");
    const saved = consumeOAuthState(cleanText(req.body.state, 160), "apple");
    if (!saved || !req.body.code) return oauthFailure(res, "oauth-state");
    const form = new URLSearchParams({
      client_id: process.env.APPLE_CLIENT_ID,
      client_secret: await appleClientSecret(),
      code: cleanText(req.body.code, 2000),
      grant_type: "authorization_code",
      redirect_uri: baseUrl + "/api/auth/apple/callback"
    });
    const tokenResponse = await fetch("https://appleid.apple.com/auth/token", {
      method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: form
    });
    if (!tokenResponse.ok) return oauthFailure(res, "apple-token");
    const tokenData = await tokenResponse.json();
    const verified = await jwtVerify(tokenData.id_token, appleJwks, { issuer: "https://appleid.apple.com", audience: process.env.APPLE_CLIENT_ID });
    if (verified.payload.nonce !== saved.nonce) return oauthFailure(res, "apple-verification");
    if (!(verified.payload.email_verified === true || verified.payload.email_verified === "true")) return oauthFailure(res, "apple-verification");
    let firstLogin = {};
    if (req.body.user) { try { firstLogin = JSON.parse(req.body.user); } catch {} }
    const fullName = [firstLogin.name && firstLogin.name.firstName, firstLogin.name && firstLogin.name.lastName].filter(Boolean).join(" ");
    const user = ensureOAuthAccount("apple", verified.payload.sub, verified.payload.email, fullName);
    if (!user.is_active) return oauthFailure(res, "account-disabled");
    await saveLogin(req, user); res.redirect(clientUrl + "/");
  } catch (error) { console.error("Apple OAuth:", error.message); oauthFailure(res, "apple-failed"); }
});

app.get("/api/products", (_req, res) => {
  res.json({ products: db.prepare("SELECT * FROM products WHERE active=1 ORDER BY id").all().map(publicProduct) });
});
app.get("/api/orders/mine", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC").all(req.user.id);
  res.json({ orders: rows.map(orderWithItems) });
});
app.post("/api/orders", requireAuth, async (req, res) => {
  const items = Array.isArray(req.body.items) ? req.body.items : [];
  const customerName = cleanText(req.body.customerName, 100) || req.user.name;
  const phone = cleanText(req.body.phone, 30), city = cleanText(req.body.city, 80), address = cleanText(req.body.address, 240);
  const promo = cleanText(req.body.promo, 20).toUpperCase();
  if (!items.length || items.length > 40) return apiError(res, 400, "Корзина пуста или слишком большая.");
  if (!city || !address) return apiError(res, 400, "Укажите город и адрес доставки.");
  const normalized = new Map();
  for (const item of items) {
    const id = Number(item.id), quantity = Number(item.quantity);
    if (!Number.isSafeInteger(id) || !Number.isSafeInteger(quantity) || quantity < 1 || quantity > 99) return apiError(res, 400, "Проверьте количество товаров.");
    normalized.set(id, (normalized.get(id) || 0) + quantity);
  }
  const orderId = "FORM-" + crypto.randomUUID().slice(0, 8).toUpperCase();
  try {
    const createOrder = db.transaction(() => {
      const rows = []; let subtotal = 0;
      for (const [id, quantity] of normalized) {
        const product = db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(id);
        if (!product) throw new Error("Товар больше не продаётся.");
        if (product.stock < quantity) throw new Error(product.name + ": в наличии только " + product.stock + " шт.");
        rows.push({ product, quantity }); subtotal += product.price * quantity;
      }
      const discount = promo === "FORM10" ? Math.round(subtotal * 0.1) : 0;
      db.prepare("INSERT INTO orders (id,user_id,status,total,subtotal,discount,customer_name,phone,city,address) VALUES (?,?,'Оформлен (демо)',?,?,?,?,?,?,?)")
        .run(orderId, req.user.id, subtotal - discount, subtotal, discount, customerName, phone, city, address);
      const insertItem = db.prepare("INSERT INTO order_items (order_id,product_id,name_snapshot,quantity,unit_price) VALUES (?,?,?,?,?)");
      const lowerStock = db.prepare("UPDATE products SET stock=stock-?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND stock>=?");
      for (const entry of rows) {
        const result = lowerStock.run(entry.quantity, entry.product.id, entry.quantity);
        if (result.changes !== 1) throw new Error(entry.product.name + ": остаток изменился. Обновите корзину.");
        insertItem.run(orderId, entry.product.id, entry.product.name, entry.quantity, entry.product.price);
        insertMovement(entry.product.id, entry.product.name, "Продажа", -entry.quantity, entry.product.stock - entry.quantity, orderId);
      }
    });
    createOrder();
  } catch (error) { return apiError(res, 409, error.message || "Не удалось оформить заказ."); }
  const email = await sendOrderNotification(db, orderId, "created");
  res.status(201).json({ order: orderWithItems(db.prepare("SELECT * FROM orders WHERE id=?").get(orderId)), emailSent: email.sent, customerEmailSent: email.customerSent });
});

function cancelOrder(orderId) {
  const cancel = db.transaction((id) => {
    const order = db.prepare("SELECT * FROM orders WHERE id=?").get(id);
    if (!order || order.canceled_at || order.status === "Выдано") throw new Error("Заказ уже отменён, не найден или выдан.");
    for (const item of db.prepare("SELECT * FROM order_items WHERE order_id=?").all(id)) {
      const product = db.prepare("SELECT * FROM products WHERE id=?").get(item.product_id);
      if (!product) throw new Error("Товар из заказа не найден; возврат отменён.");
      const balance = product.stock + item.quantity;
      db.prepare("UPDATE products SET stock=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(balance, item.product_id);
      insertMovement(item.product_id, product.name, "Возврат", item.quantity, balance, id + " · отмена");
    }
    db.prepare("UPDATE orders SET status='Отменён',canceled_at=CURRENT_TIMESTAMP WHERE id=?").run(id);
  });
  cancel(orderId);
}

app.post("/api/orders/:id/cancel", requireAuth, async (req, res) => {
  const order = db.prepare("SELECT id,user_id FROM orders WHERE id=?").get(cleanText(req.params.id, 40));
  if (!order || order.user_id !== req.user.id) return apiError(res, 404, "Заказ не найден.");
  try {
    cancelOrder(order.id);
    const email = await sendOrderNotification(db, order.id, "canceled");
    res.json({ ok: true, emailSent: email.sent });
  } catch (error) { apiError(res, 409, error.message || "Не удалось отменить заказ."); }
});

app.get("/api/admin/overview", requireAuth, requireAdmin, (_req, res) => {
  const totals = db.prepare("SELECT COUNT(*) AS products,COALESCE(SUM(stock),0) AS units,SUM(CASE WHEN stock<=3 THEN 1 ELSE 0 END) AS lowStock FROM products WHERE active=1").get();
  const orders = db.prepare("SELECT COUNT(*) AS count,COALESCE(SUM(CASE WHEN canceled_at IS NULL THEN total ELSE 0 END),0) AS revenue FROM orders").get();
  const users = db.prepare("SELECT COUNT(*) AS count FROM users WHERE role='customer'").get();
  res.json({ ...totals, orderCount: orders.count, revenue: orders.revenue, userCount: users.count });
});
app.get("/api/admin/products", requireAuth, requireAdmin, (_req, res) => {
  res.json({ products: db.prepare("SELECT * FROM products ORDER BY active DESC,name COLLATE NOCASE").all().map(publicProduct) });
});
app.post("/api/admin/products", requireAuth, requireAdmin, (req, res) => {
  try {
    const data = productBody(req.body);
    const id = db.prepare("SELECT COALESCE(MAX(id),0)+1 AS id FROM products").get().id;
    db.prepare("INSERT INTO products (id,name,category,subtitle,brand,price,badge,image,tags_json,description,source,fresh,specs_json,in_the_box,warranty,delivery,stock) VALUES (@id,@name,@category,@subtitle,@brand,@price,@badge,@image,@tags_json,@description,@source,@fresh,@specs_json,@in_the_box,@warranty,@delivery,@stock)")
      .run({ ...data, id, tags_json: JSON.stringify(data.tags), specs_json: JSON.stringify(data.specs), in_the_box: data.inTheBox, fresh: data.fresh ? 1 : 0 });
    insertMovement(id, data.name, "Поступление", data.stock, data.stock, "Новый товар");
    res.status(201).json({ product: publicProduct(db.prepare("SELECT * FROM products WHERE id=?").get(id)) });
  } catch (error) { apiError(res, 400, error.message || "Не удалось добавить товар."); }
});
app.patch("/api/admin/products/:id", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id), row = db.prepare("SELECT * FROM products WHERE id=?").get(id);
  if (!row) return apiError(res, 404, "Товар не найден.");
  try {
    const data = productBody(req.body, productFromRow(row));
    const active = req.body.active === undefined ? Boolean(row.active) : Boolean(req.body.active);
    db.prepare("UPDATE products SET name=@name,category=@category,subtitle=@subtitle,brand=@brand,price=@price,badge=@badge,image=@image,tags_json=@tags_json,description=@description,source=@source,fresh=@fresh,specs_json=@specs_json,in_the_box=@in_the_box,warranty=@warranty,delivery=@delivery,stock=@stock,active=@active,updated_at=CURRENT_TIMESTAMP WHERE id=@id")
      .run({ ...data, id, tags_json: JSON.stringify(data.tags), specs_json: JSON.stringify(data.specs), in_the_box: data.inTheBox, fresh: data.fresh ? 1 : 0, active: active ? 1 : 0 });
    if (row.stock !== data.stock) insertMovement(id, data.name, "Корректировка", data.stock - row.stock, data.stock, "Администратор изменил остаток");
    res.json({ product: publicProduct(db.prepare("SELECT * FROM products WHERE id=?").get(id)) });
  } catch (error) { apiError(res, 400, error.message || "Не удалось изменить товар."); }
});
app.delete("/api/admin/products/:id", requireAuth, requireAdmin, (req, res) => {
  const result = db.prepare("UPDATE products SET active=0,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(Number(req.params.id));
  if (!result.changes) return apiError(res, 404, "Товар не найден.");
  res.json({ ok: true });
});
app.get("/api/admin/users", requireAuth, requireAdmin, (_req, res) => {
  const users = db.prepare("SELECT * FROM users ORDER BY created_at DESC").all();
  res.json({ users: users.map((u) => ({ ...publicUser(u), isActive: Boolean(u.is_active), orderCount: db.prepare("SELECT COUNT(*) AS count FROM orders WHERE user_id=?").get(u.id).count })) });
});
app.patch("/api/admin/users/:id", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id), user = db.prepare("SELECT * FROM users WHERE id=?").get(id);
  if (!user) return apiError(res, 404, "Аккаунт не найден.");
  const name = cleanText(req.body.name, 100), email = emailValue(req.body.email);
  const active = req.body.isActive === undefined ? user.is_active : (req.body.isActive ? 1 : 0);
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return apiError(res, 400, "Проверьте имя и email.");
  if (user.id === req.user.id && !active) return apiError(res, 400, "Нельзя отключить текущий аккаунт администратора.");
  try {
    db.prepare("UPDATE users SET name=?,email=?,is_active=? WHERE id=?").run(name, email, active, id);
    res.json({ user: publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(id)) });
  } catch (error) {
    if (String(error.code).includes("SQLITE_CONSTRAINT")) return apiError(res, 409, "Этот email уже используется.");
    apiError(res, 500, "Не удалось сохранить пользователя.");
  }
});
app.get("/api/admin/orders", requireAuth, requireAdmin, (_req, res) => {
  const rows = db.prepare("SELECT orders.*,users.name AS account_name,users.email FROM orders JOIN users ON users.id=orders.user_id ORDER BY orders.created_at DESC LIMIT 500").all();
  res.json({ orders: rows.map((order) => ({ ...orderWithItems(order), accountName: order.account_name, email: order.email })) });
});
const allowedStatuses = new Set(["Оформлен (демо)", "Оплачено (демо)", "Собирается", "Отправлено", "Выдано"]);
app.patch("/api/admin/orders/:id", requireAuth, requireAdmin, async (req, res) => {
  const status = cleanText(req.body.status, 40);
  if (!allowedStatuses.has(status)) return apiError(res, 400, "Недопустимый статус заказа.");
  const order = db.prepare("SELECT * FROM orders WHERE id=?").get(req.params.id);
  if (!order || order.canceled_at) return apiError(res, 404, "Заказ не найден или уже отменён.");
  if (order.status === status) return res.json({ ok: true, changed: false });
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(status, order.id);
  const email = await sendOrderNotification(db, order.id, "status", status);
  res.json({ ok: true, emailSent: email.sent });
});
app.post("/api/admin/orders/:id/cancel", requireAuth, requireAdmin, async (req, res) => {
  try {
    cancelOrder(cleanText(req.params.id, 40));
    const email = await sendOrderNotification(db, req.params.id, "canceled");
    res.json({ ok: true, emailSent: email.sent });
  }
  catch (error) { apiError(res, 409, error.message); }
});
app.get("/api/admin/movements", requireAuth, requireAdmin, (_req, res) => {
  res.json({ movements: db.prepare("SELECT * FROM stock_movements ORDER BY id DESC LIMIT 1000").all() });
});
app.get("/api/admin/mail/status", requireAuth, requireAdmin, async (_req, res) => {
  const config = mailConfiguration();
  res.json({
    configured: config.configured,
    sender: config.user || "",
    recipient: config.recipient,
    verification: config.configured ? await verifyMailConfiguration() : { ok: false, error: "Почта пока не настроена." },
    notifications: db.prepare("SELECT id,order_id,event,recipient,subject,status,error,created_at,sent_at FROM email_notifications ORDER BY id DESC LIMIT 100").all(),
  });
});
app.post("/api/admin/mail/test", requireAuth, requireAdmin, async (_req, res) => {
  const result = await sendTestEmail();
  if (!result.sent) return apiError(res, 503, result.error || "Тестовое письмо не отправлено.");
  res.json({ ok: true });
});

installFeatures(app, db, { requireAuth, requireAdmin, userFromRequest });

app.use("/api", (_req, res) => apiError(res, 404, "API маршрут не найден."));
const publicDir = path.resolve(here, "../public");
app.get("/admin", (_req, res) => res.sendFile(path.join(publicDir, "admin.html")));
app.use(express.static(publicDir));
app.use((req, res, next) => {
  if (req.method === "GET" && req.accepts("html")) return res.sendFile(path.join(publicDir, "index.html"));
  next();
});
app.use((error, _req, res, _next) => { console.error(error); apiError(res, 500, "Внутренняя ошибка сервера."); });
app.listen(port, "127.0.0.1", () => {
  console.log("Form shop API ready at http://localhost:" + port);
  console.log("SQLite file: " + path.relative(process.cwd(), process.env.DATABASE_FILE || "server/data/store.sqlite"));
});
