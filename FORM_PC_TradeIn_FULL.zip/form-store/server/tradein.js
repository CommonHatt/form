// Прозрачная предварительная оценка Trade-in по анкете клиента.
// Фотографии используются для ручного осмотра менеджером, а не для автоматического распознавания дефектов.
export const DEVICE_TYPES = ["smartphone", "laptop", "desktop", "tablet", "console", "monitor", "accessory", "other"];
export const CONDITIONS = ["excellent", "good", "fair", "poor"];
export const WORKING_STATES = ["yes", "limited", "no"];
export const DEFECTS = ["scratches", "dents", "screen", "battery", "ports", "overheating", "liquid", "repairs", "other"];
const decay = { smartphone: 0.72, laptop: 0.81, desktop: 0.81, tablet: 0.77, console: 0.84, monitor: 0.87, accessory: 0.72, other: 0.77 };
const conditionFactor = { excellent: 1, good: 0.86, fair: 0.68, poor: 0.43 };
const defectFactor = { scratches: 0.96, dents: 0.91, screen: 0.66, battery: 0.86, ports: 0.84, overheating: 0.66, liquid: 0.54, repairs: 0.85, other: 0.9 };
const names = {
  scratches: "потёртости и царапины", dents: "вмятины", screen: "повреждение экрана", battery: "износ аккумулятора",
  ports: "неисправные разъёмы", overheating: "перегрев", liquid: "следы попадания жидкости",
  repairs: "предыдущий ремонт", other: "другие недостатки"
};
export function validMonth(value, now = new Date()) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(value))) return false;
  const [y, m] = value.split("-").map(Number);
  return y >= 1995 && (y < now.getFullYear() || (y === now.getFullYear() && m <= now.getMonth() + 1));
}
export function normalizeTradein(body, now = new Date()) {
  const clean = (v, limit) => typeof v === "string" ? v.trim().slice(0, limit) : "";
  const type = clean(body.deviceType, 30), condition = clean(body.condition, 30), working = clean(body.working, 20);
  const purchaseMonth = clean(body.purchaseMonth, 7);
  const price = body.originalPrice === "" || body.originalPrice == null ? null : Number(body.originalPrice);
  if (!DEVICE_TYPES.includes(type)) throw new Error("Выберите тип устройства.");
  if (!clean(body.brand, 80) || !clean(body.model, 120)) throw new Error("Укажите бренд и модель устройства.");
  if (!validMonth(purchaseMonth, now)) throw new Error("Укажите корректный месяц покупки.");
  if (!CONDITIONS.includes(condition) || !WORKING_STATES.includes(working)) throw new Error("Укажите состояние и работоспособность.");
  if (price !== null && (!Number.isSafeInteger(price) || price < 1000 || price > 100000000)) throw new Error("Цена покупки должна быть от 1 000 до 100 000 000 ₸.");
  const defects = [...new Set((Array.isArray(body.defects) ? body.defects : []).filter((x) => DEFECTS.includes(x)))];
  return {
    deviceType: type, brand: clean(body.brand, 80), model: clean(body.model, 120), purchaseMonth,
    originalPrice: price, condition, working, defects,
    notes: clean(body.notes, 1500), hasCharger: Boolean(body.hasCharger), hasBox: Boolean(body.hasBox)
  };
}
const round = (v) => Math.max(0, Math.round(v / 1000) * 1000);
export function estimateTradein(input, now = new Date()) {
  const data = normalizeTradein(input, now);
  const [year, month] = data.purchaseMonth.split("-").map(Number);
  const months = Math.max(0, (now.getFullYear() - year) * 12 + now.getMonth() + 1 - month);
  const age = +(months / 12).toFixed(1);
  const summary = [`Устройству примерно ${months} мес.`, `Состояние: ${({ excellent:"отличное", good:"хорошее", fair:"с заметным износом", poor:"сильный износ" })[data.condition]}.`];
  if (data.defects.length) summary.push("Заявленные недостатки: " + data.defects.map((d) => names[d]).join(", ") + ".");
  if (data.working === "limited") summary.push("Работает с ограничениями — требуется диагностика.");
  if (data.working === "no") summary.push("Не включается: оценивается как устройство для диагностики или ремонта.");
  if (!data.hasCharger && ["laptop", "smartphone", "tablet"].includes(data.deviceType)) summary.push("Нет оригинального зарядного устройства.");
  let low = null, high = null;
  if (data.originalPrice !== null) {
    const ageFactor = Math.pow(decay[data.deviceType], months / 12);
    const wear = data.defects.reduce((f, defect) => f * defectFactor[defect], 1);
    const work = data.working === "no" ? 0.16 : data.working === "limited" ? 0.65 : 1;
    const charger = !data.hasCharger && ["laptop", "smartphone", "tablet"].includes(data.deviceType) ? 0.94 : 1;
    const packaging = data.hasBox ? 1 : 0.98;
    const mean = data.originalPrice * 0.78 * ageFactor * conditionFactor[data.condition] * wear * work * charger * packaging;
    low = round(Math.min(mean * 0.85, data.originalPrice));
    high = round(Math.min(mean * 1.10, data.originalPrice));
    if (high < low) high = low;
    summary.push("Расчёт использует указанную цену покупки, возраст и анкету, а не актуальные рыночные предложения.");
  } else summary.push("Без исходной цены покупки денежный диапазон не рассчитывается.");
  const highRisk = data.working !== "yes" || ["screen", "overheating", "liquid"].some((d) => data.defects.includes(d));
  const verdict = highRisk ? "Нужна техническая диагностика" : data.condition === "excellent" && !data.defects.length ? "Хорошее состояние по анкете" : "Возможен обмен после осмотра";
  return {
    low, high, ageMonths: months, ageYears: age, verdict, reasoning: summary,
    disclaimer: "Демо-оценка, не оферта и не обещание выплаты. Фотографии не анализируются автоматически. Окончательную цену определяет менеджер после проверки состояния, серийного номера, комплектации и рынка."
  };
}
