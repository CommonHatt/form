// Формирование сборок из реальных позиций каталога FORM.
// Проверяются только известные характеристики — отсутствие данных не считается доказанной совместимостью.
export const GROUPS = Object.freeze([
  { key: "cpu", name: "Процессор", required: true },
  { key: "motherboard", name: "Материнская плата", required: true },
  { key: "gpu", name: "Видеокарта", required: true },
  { key: "ram", name: "Оперативная память", required: true },
  { key: "storage", name: "Накопитель", required: true },
  { key: "psu", name: "Блок питания", required: true },
  { key: "cooling", name: "Охлаждение", required: true },
  { key: "case", name: "Корпус", required: true }
]);
const groupKeys = new Set(GROUPS.map((g) => g.key));
const fixedGroup = { 31: "case", 22: "cpu", 23: "cpu", 24: "gpu", 25: "gpu", 26: "motherboard", 27: "ram", 28: "storage", 29: "psu", 30: "cooling" };
export function productGroup(product) {
  if (!product || product.category !== "component") return null;
  if (fixedGroup[product.id]) return fixedGroup[product.id];
  const title = String(product.name || "").toLowerCase();
  if (/корпус|\bcase\b|fractal design|nzxt h\d+|lian li/.test(title)) return "case";
  if (/материн|motherboard|\b[bzx][5-9]\d{2}\b|\brog strix [bxz]\d{3}/.test(title)) return "motherboard";
  if (/geforce|radeon|\brtx\b|видеокарт|\brx\s?\d{4}/.test(title)) return "gpu";
  if (/\bryzen\b|\bthreadripper\b|процессор|\bcore (i\d|ultra)\b/.test(title)) return "cpu";
  if (/\bddr[45]\b|оператив|kingston fury|\bvengeance\b/.test(title)) return "ram";
  if (/\bssd\b|\bnvme\b|\bm\.2\b|\b990 pro\b|\bsn850\b|накопител/.test(title)) return "storage";
  if (/блок питания|\bpsu\b|\brm\d{3}\b|\b\d{3,4}\s?(w|вт)\b/.test(title)) return "psu";
  if (/охлажден|кулер|\bcooler\b|\bliquid\b|\bh150\b|\bkraken\b|\bi?cue\b/.test(title)) return "cooling";
  return null;
}
export function cleanSelection(value) {
  const chosen = {};
  if (!value || typeof value !== "object" || Array.isArray(value)) return chosen;
  for (const key of groupKeys) {
    const id = Number(value[key]);
    if (Number.isSafeInteger(id) && id > 0) chosen[key] = id;
  }
  return chosen;
}
function infoText(product) {
  return [product?.name, ...(product?.tags || []), ...(product?.specs || []).flatMap((r) => Array.isArray(r) ? r : [])].filter(Boolean).join(" ").toUpperCase();
}
function socket(product) {
  const match = infoText(product).match(/\b(AM[45]|LGA\s?\d{4})\b/);
  return match ? match[1].replace(/\s/g, "") : null;
}
function ramType(product) {
  const match = infoText(product).match(/\b(DDR[345])\b/);
  return match ? match[1] : null;
}
function wattage(product) {
  if (!product) return null;
  const match = infoText(product).match(/\b(\d{3,4})\s*(?:W|ВТ|ВАТТ)\b/);
  return match ? Number(match[1]) : null;
}
function recommendedPsu(gpu) {
  if (!gpu) return null;
  const row = (gpu.specs || []).find((r) => Array.isArray(r) && /рекоменд.*бп|recommended.*psu/i.test(r[0]));
  if (!row) return null;
  const match = String(row[1]).match(/(\d{3,4})/);
  return match ? Number(match[1]) : null;
}
export function evaluateBuild(rawSelection, catalog) {
  const selected = cleanSelection(rawSelection);
  const byId = new Map(catalog.map((p) => [Number(p.id), p]));
  const items = {};
  const alerts = [];
  const warn = (severity, message) => alerts.push({ severity, message });
  for (const group of GROUPS) {
    const id = selected[group.key];
    if (!id) { if (group.required) warn("warning", `Не выбрано: ${group.name.toLowerCase()}.`); continue; }
    const product = byId.get(id);
    if (!product || productGroup(product) !== group.key) {
      warn("error", `В разделе «${group.name}» выбран неподходящий или удалённый товар.`);
      continue;
    }
    items[group.key] = product;
    if (!product.active || !Number(product.stock)) warn("error", `${product.name}: нет в наличии.`);
  }
  if (items.cpu && items.motherboard) {
    const a = socket(items.cpu), b = socket(items.motherboard);
    if (a && b && a !== b) warn("error", `Несовместимые сокеты: процессор ${a}, плата ${b}.`);
    else if (a && b) warn("ok", `Процессор и материнская плата используют сокет ${a}.`);
    else warn("warning", "Сокет процессора и платы нужно проверить по характеристикам производителя.");
  }
  if (items.motherboard && items.ram) {
    const a = ramType(items.motherboard), b = ramType(items.ram);
    if (a && b && a !== b) warn("error", `Память ${b} не соответствует стандарту платы ${a}.`);
    else if (a && b) warn("ok", `Тип оперативной памяти совпадает: ${a}.`);
    else warn("warning", "Поддержку выбранной оперативной памяти необходимо проверить вручную.");
  }
  if (items.cpu && items.cooling) {
    const a = socket(items.cpu), support = infoText(items.cooling);
    if (a && /\b(AM[45]|LGA\s?\d{4})\b/.test(support)) {
      if (!support.includes(a)) warn("error", `Для охлаждения не указана поддержка сокета ${a}.`);
      else warn("ok", `Охлаждение поддерживает ${a}.`);
    } else warn("warning", "Нужно проверить крепление охлаждения для сокета процессора.");
  }
  if (items.psu && items.gpu) {
    const power = wattage(items.psu), needed = recommendedPsu(items.gpu);
    if (power && needed) {
      if (power < needed) warn("error", `Для видеокарты рекомендован БП от ${needed} Вт, выбран ${power} Вт.`);
      else warn("ok", `Мощность БП ${power} Вт соответствует рекомендации видеокарты ${needed} Вт.`);
    } else warn("warning", "Проверьте потребление видеокарты, разъёмы и мощность блока питания вручную.");
  }
  if (items.case && items.motherboard) warn("warning", "Форм-фактор материнской платы, длину видеокарты и габариты охлаждения необходимо сверить с корпусом.");
  else if (items.cooling) warn("warning", "Без корпуса нельзя проверить, поместится ли радиатор и видеокарта.");
  if (items.storage && items.motherboard) warn("warning", "Проверьте свободный слот M.2/SATA и его поколение на материнской плате.");
  const total = Object.values(items).reduce((sum, p) => sum + Number(p.price || 0), 0);
  const errors = alerts.filter((a) => a.severity === "error").length;
  const missing = GROUPS.filter((g) => g.required && !items[g.key]).length;
  return {
    selected, items, alerts, total, errors, missing,
    ready: errors === 0 && missing === 0,
    verdict: errors ? "Есть несовместимости или товары отсутствуют" : missing ? "Сборка не завершена" : "Предварительная проверка пройдена",
    disclaimer: "Это предварительная проверка по заполненным данным каталога, а не гарантия совместимости. Перед покупкой проверьте BIOS, размеры, разъёмы, охлаждение и питание. Заказы на сайте демонстрационные."
  };
}
