import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import rateLimit from "express-rate-limit";
import { productFromRow } from "./db.js";
import { GROUPS, productGroup, evaluateBuild, cleanSelection } from "./pc.js";
import { normalizeTradein, estimateTradein } from "./tradein.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const photoDir = path.join(here, "data", "tradein-uploads");
fs.mkdirSync(photoDir, { recursive: true });
const statuses = new Set(["new", "in_review", "offer_sent", "accepted", "rejected"]);
const bad = (res, code, message) => res.status(code).json({ error: message });
const clean = (v, len = 150) => typeof v === "string" ? v.trim().slice(0, len) : "";
const validId = (value) => Number.isSafeInteger(Number(value)) && Number(value) > 0 ? Number(value) : null;
const productColumns = "id,name,category,subtitle,brand,price,badge,image,tags_json,description,source,fresh,specs_json,in_the_box,warranty,delivery,stock,active";
const parseJson = (s, fallback = []) => { try { return JSON.parse(s); } catch { return fallback; } };

function parsePhoto(data) {
  if (typeof data !== "string" || data.length > 3_000_000) throw new Error("Фотография слишком большая (до 2 МБ).");
  const match = data.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/);
  if (!match) throw new Error("Разрешены только фотографии JPG, PNG и WebP.");
  const buffer = Buffer.from(match[2], "base64");
  if (buffer.length < 30 || buffer.length > 2_000_000) throw new Error("Размер каждого фото должен быть до 2 МБ.");
  const jpeg = buffer.length > 4 && buffer[0] === 255 && buffer[1] === 216 && buffer[2] === 255;
  const png = buffer.subarray(0, 8).equals(Buffer.from("89504e470d0a1a0a", "hex"));
  const webp = buffer.toString("ascii", 0, 4) === "RIFF" && buffer.toString("ascii", 8, 12) === "WEBP";
  const mime = match[1];
  if (!((mime === "image/jpeg" && jpeg) || (mime === "image/png" && png) || (mime === "image/webp" && webp))) {
    throw new Error("Содержимое фотографии не соответствует формату.");
  }
  return { buffer, mime, extension: mime === "image/jpeg" ? "jpg" : mime.split("/")[1] };
}

export function installFeatures(app, db, { requireAuth, requireAdmin, userFromRequest }) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS pc_builds (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      selection_json TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_pc_builds_user ON pc_builds(user_id,updated_at);
    CREATE TABLE IF NOT EXISTS tradein_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      customer_name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT NOT NULL,
      device_type TEXT NOT NULL, brand TEXT NOT NULL, model TEXT NOT NULL,
      purchase_month TEXT NOT NULL, original_price INTEGER,
      condition TEXT NOT NULL, working TEXT NOT NULL, defects_json TEXT NOT NULL,
      notes TEXT NOT NULL DEFAULT '', has_charger INTEGER NOT NULL DEFAULT 0, has_box INTEGER NOT NULL DEFAULT 0,
      estimate_low INTEGER, estimate_high INTEGER, verdict TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'new', admin_offer INTEGER, manager_note TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_tradein_user ON tradein_requests(user_id,created_at);
    CREATE INDEX IF NOT EXISTS idx_tradein_status ON tradein_requests(status,created_at);
    CREATE TABLE IF NOT EXISTS tradein_photos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tradein_id INTEGER NOT NULL REFERENCES tradein_requests(id) ON DELETE CASCADE,
      file_name TEXT NOT NULL UNIQUE, mime TEXT NOT NULL, size INTEGER NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
  `);

  const listProducts = () => db.prepare(`SELECT ${productColumns} FROM products WHERE active=1 AND category='component' ORDER BY id`).all().map((row) => ({ ...productFromRow(row), active: Boolean(row.active) }));
  app.get("/api/pc/catalog", (_req, res) => {
    const components = listProducts().map((p) => ({ ...p, group: productGroup(p) })).filter((p) => p.group);
    res.json({ groups: GROUPS, components });
  });
  app.get("/api/pc/check", (req, res) => {
    res.json(evaluateBuild(req.query, listProducts()));
  });
  app.get("/api/pc/builds", requireAuth, (req, res) => {
    const rows = db.prepare("SELECT id,name,selection_json,created_at,updated_at FROM pc_builds WHERE user_id=? ORDER BY updated_at DESC LIMIT 50").all(req.user.id);
    res.json({ builds: rows.map((r) => ({ id: r.id, name: r.name, selection: parseJson(r.selection_json, {}), createdAt: r.created_at, updatedAt: r.updated_at })) });
  });
  app.post("/api/pc/builds", requireAuth, (req, res) => {
    const name = clean(req.body?.name, 80), selection = cleanSelection(req.body?.selection);
    if (!name || Object.keys(selection).length === 0) return bad(res, 400, "Укажите название и выберите хотя бы один компонент.");
    if (db.prepare("SELECT COUNT(*) AS n FROM pc_builds WHERE user_id=?").get(req.user.id).n >= 50) return bad(res, 409, "Можно сохранить максимум 50 сборок.");
    const estimate = evaluateBuild(selection, listProducts());
    if (estimate.errors) return bad(res, 409, "В сборке есть недоступные или несовместимые компоненты. Исправьте их перед сохранением.");
    const row = db.prepare("INSERT INTO pc_builds (user_id,name,selection_json) VALUES (?,?,?)").run(req.user.id, name, JSON.stringify(selection));
    res.status(201).json({ id: Number(row.lastInsertRowid), name, selection });
  });
  app.delete("/api/pc/builds/:id", requireAuth, (req, res) => {
    const result = db.prepare("DELETE FROM pc_builds WHERE id=? AND user_id=?").run(req.params.id, req.user.id);
    if (!result.changes) return bad(res, 404, "Сборка не найдена.");
    res.json({ ok: true });
  });

  app.post("/api/tradein/estimate", (req, res) => {
    try { res.json(estimateTradein(req.body || {})); }
    catch (error) { bad(res, 400, error.message); }
  });
  const submitLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 8, standardHeaders: "draft-8", legacyHeaders: false, message: { error: "Слишком много заявок. Попробуйте позднее." } });
  app.post("/api/tradein/requests", submitLimiter, (req, res) => {
    let photoFiles = [];
    try {
      const form = normalizeTradein(req.body || {});
      const name = clean(req.body.customerName, 100), email = clean(req.body.email, 254).toLowerCase(), phone = clean(req.body.phone, 35);
      if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || phone.replace(/\D/g, "").length < 10) {
        throw new Error("Укажите имя, корректную почту и номер телефона.");
      }
      if (!Array.isArray(req.body.photos) || req.body.photos.length < 1 || req.body.photos.length > 4) {
        throw new Error("Прикрепите от 1 до 4 фотографий устройства.");
      }
      photoFiles = req.body.photos.map(parsePhoto);
      const estimate = estimateTradein(form);
      const user = userFromRequest(req);
      const insertRequest = db.prepare(`INSERT INTO tradein_requests
        (user_id,customer_name,email,phone,device_type,brand,model,purchase_month,original_price,condition,working,defects_json,notes,has_charger,has_box,estimate_low,estimate_high,verdict)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
      const insertPhoto = db.prepare("INSERT INTO tradein_photos (tradein_id,file_name,mime,size) VALUES (?,?,?,?)");
      const filesCreated = [];
      let id;
      try {
        const persist = db.transaction(() => {
          const result = insertRequest.run(user?.id || null, name, email, phone, form.deviceType, form.brand, form.model, form.purchaseMonth,
            form.originalPrice, form.condition, form.working, JSON.stringify(form.defects), form.notes, form.hasCharger ? 1 : 0,
            form.hasBox ? 1 : 0, estimate.low, estimate.high, estimate.verdict);
          id = Number(result.lastInsertRowid);
          for (const photo of photoFiles) {
            const filename = `${crypto.randomUUID()}.${photo.extension}`;
            fs.writeFileSync(path.join(photoDir, filename), photo.buffer, { flag: "wx" });
            filesCreated.push(filename);
            insertPhoto.run(id, filename, photo.mime, photo.buffer.length);
          }
        });
        persist();
      } catch (error) { for (const file of filesCreated) { try { fs.unlinkSync(path.join(photoDir, file)); } catch {} } throw error; }
      res.status(201).json({ ok: true, id, status: "new", estimate });
    } catch (error) { bad(res, 400, error.message || "Не удалось отправить заявку."); }
  });
  const listRow = (r) => ({
    id: r.id, userId: r.user_id, customerName: r.customer_name, email: r.email, phone: r.phone,
    deviceType: r.device_type, brand: r.brand, model: r.model, purchaseMonth: r.purchase_month,
    originalPrice: r.original_price, condition: r.condition, working: r.working, defects: parseJson(r.defects_json),
    notes: r.notes, hasCharger: !!r.has_charger, hasBox: !!r.has_box,
    estimateLow: r.estimate_low, estimateHigh: r.estimate_high, verdict: r.verdict,
    status: r.status, adminOffer: r.admin_offer, managerNote: r.manager_note,
    createdAt: r.created_at, updatedAt: r.updated_at,
    photos: db.prepare("SELECT id,mime,size FROM tradein_photos WHERE tradein_id=? ORDER BY id").all(r.id).map((p) => ({
      id: p.id, url: `/api/tradein/${r.id}/photos/${p.id}`
    }))
  });
  app.get("/api/tradein/mine", requireAuth, (req, res) => {
    const rows = db.prepare("SELECT * FROM tradein_requests WHERE user_id=? ORDER BY id DESC LIMIT 100").all(req.user.id);
    res.json({ requests: rows.map(listRow) });
  });
  app.get("/api/admin/tradein", requireAuth, requireAdmin, (_req, res) => {
    res.json({ requests: db.prepare("SELECT * FROM tradein_requests ORDER BY id DESC LIMIT 300").all().map(listRow) });
  });
  app.patch("/api/admin/tradein/:id", requireAuth, requireAdmin, (req, res) => {
    const id = validId(req.params.id), row = db.prepare("SELECT * FROM tradein_requests WHERE id=?").get(id);
    if (!row) return bad(res, 404, "Заявка не найдена.");
    const status = clean(req.body?.status, 30);
    if (!statuses.has(status)) return bad(res, 400, "Недопустимый статус.");
    const offer = req.body?.adminOffer === "" || req.body?.adminOffer === null || req.body?.adminOffer === undefined ? null : Number(req.body.adminOffer);
    if (offer !== null && (!Number.isSafeInteger(offer) || offer < 0 || offer > 100000000)) return bad(res, 400, "Укажите сумму от 0 до 100 млн ₸.");
    const note = clean(req.body?.managerNote, 2000);
    db.prepare("UPDATE tradein_requests SET status=?,admin_offer=?,manager_note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(status, offer, note, id);
    res.json({ request: listRow(db.prepare("SELECT * FROM tradein_requests WHERE id=?").get(id)) });
  });
  app.get("/api/tradein/:id/photos/:photoId", requireAuth, (req, res) => {
    const id = validId(req.params.id), photoId = validId(req.params.photoId);
    const request = db.prepare("SELECT user_id FROM tradein_requests WHERE id=?").get(id);
    if (!request || (req.user.role !== "admin" && request.user_id !== req.user.id)) return bad(res, 404, "Фото не найдено.");
    const photo = db.prepare("SELECT * FROM tradein_photos WHERE tradein_id=? AND id=?").get(id, photoId);
    if (!photo || !/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(photo.file_name)) return bad(res, 404, "Фото не найдено.");
    res.set({ "Content-Type": photo.mime, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff", "Content-Security-Policy": "default-src 'none'" });
    return res.sendFile(path.join(photoDir, photo.file_name), (error) => { if (error && !res.headersSent) bad(res, 404, "Фото не найдено."); });
  });
  app.delete("/api/admin/tradein/:id", requireAuth, requireAdmin, (req, res) => {
    const id = validId(req.params.id), files = db.prepare("SELECT file_name FROM tradein_photos WHERE tradein_id=?").all(id);
    const result = db.prepare("DELETE FROM tradein_requests WHERE id=?").run(id);
    if (!result.changes) return bad(res, 404, "Заявка не найдена.");
    for (const file of files) { try { fs.unlinkSync(path.join(photoDir, file.file_name)); } catch {} }
    res.json({ ok: true });
  });
}
