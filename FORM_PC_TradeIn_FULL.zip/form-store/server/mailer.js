import nodemailer from "nodemailer";

let transporter;

const eventLabels = {
  created: "Новый заказ",
  canceled: "Заказ отменён",
  status: "Изменён статус заказа",
};

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

export function mailConfiguration() {
  const user = (process.env.MAIL_USER || "").trim();
  const password = (process.env.MAIL_APP_PASSWORD || "").replace(/\s+/g, "");
  const recipient = (process.env.MAIL_TO || "").trim();
  return { configured: Boolean(user && password && recipient), user, password, recipient };
}

function getTransport(config) {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: process.env.MAIL_HOST || "smtp.gmail.com",
      port: Number(process.env.MAIL_PORT || 465),
      secure: (process.env.MAIL_SECURE || "true").toLowerCase() === "true",
      auth: { user: config.user, pass: config.password },
      connectionTimeout: 12000,
      greetingTimeout: 12000,
      socketTimeout: 20000,
    });
  }
  return transporter;
}

export async function sendOrderNotification(db, orderId, event, changedStatus = "") {
  const label = eventLabels[event];
  if (!label) throw new Error("Unknown order email event.");
  const config = mailConfiguration();
  const order = db.prepare(`
    SELECT o.*,u.name AS account_name,u.email AS account_email
    FROM orders o JOIN users u ON u.id=o.user_id WHERE o.id=?
  `).get(orderId);
  if (!order) return { sent: false, reason: "order_missing" };
  const items = db.prepare("SELECT name_snapshot AS name,quantity,unit_price FROM order_items WHERE order_id=?").all(orderId);
  const subject = `${label}: ${order.id}`;
  const status = event === "status" ? changedStatus : order.status;
  const lines = [
    `Событие: ${label}`,
    `Заказ: ${order.id}`,
    `Статус: ${status}`,
    `Покупатель: ${order.customer_name} (${order.account_email})`,
    `Телефон: ${order.phone || "не указан"}`,
    `Адрес: ${order.city}, ${order.address}`,
    "",
    "Состав заказа:",
    ...items.map((item) => `• ${item.name} × ${item.quantity} — ${(item.unit_price * item.quantity).toLocaleString("ru-RU")} ₸`),
    "",
    `Итого: ${Number(order.total).toLocaleString("ru-RU")} ₸`,
    "Оплата: демонстрационный заказ, реальные средства не списывались.",
  ].join("\n");
  const rows = items.map((item) => `<tr><td style="padding:10px;border-bottom:1px solid #eee">${escapeHtml(item.name)} × ${item.quantity}</td><td style="padding:10px;border-bottom:1px solid #eee;text-align:right">${(item.unit_price * item.quantity).toLocaleString("ru-RU")} ₸</td></tr>`).join("");
  const html = `<div style="font-family:Arial,sans-serif;color:#202020;max-width:640px;margin:auto"><p style="font-size:11px;letter-spacing:.16em;color:#777">FORM · УВЕДОМЛЕНИЕ МАГАЗИНА</p><h1 style="font-size:26px">${escapeHtml(label)}</h1><p><b>${escapeHtml(order.id)}</b> · ${escapeHtml(status)}</p><hr style="border:0;border-top:1px solid #eee"><p><b>Покупатель:</b> ${escapeHtml(order.customer_name)}<br><b>Email аккаунта:</b> ${escapeHtml(order.account_email)}<br><b>Телефон:</b> ${escapeHtml(order.phone || "не указан")}<br><b>Доставка:</b> ${escapeHtml(order.city)}, ${escapeHtml(order.address)}</p><table style="width:100%;border-collapse:collapse">${rows}</table><p style="text-align:right;font-size:20px"><b>Итого: ${Number(order.total).toLocaleString("ru-RU")} ₸</b></p><p style="font-size:12px;color:#777">Демо-заказ: реальные средства не списывались. Данные банковской карты не сохранялись.</p></div>`;
  // Keep the store informed and send the buyer their own order receipt/update.
  // Separate messages avoid exposing one recipient's email address to the other.
  const recipients = [...new Map([config.recipient, order.account_email].filter(Boolean).map((email) => [email.toLowerCase(), email])).values()];
  const results = [];
  for (const recipient of recipients) {
    const row = db.prepare("INSERT INTO email_notifications (order_id,event,recipient,subject,status,error) VALUES (?,?,?,?,?,?)")
      .run(orderId, event, recipient, subject, config.configured ? "pending" : "not_configured", config.configured ? "" : "SMTP не настроен в .env");
    if (!config.configured) {
      results.push({ recipient, sent: false, notificationId: row.lastInsertRowid, reason: "not_configured" });
      continue;
    }
    try {
      await getTransport(config).sendMail({
        from: process.env.MAIL_FROM || `Form Store <${config.user}>`,
        to: recipient,
        subject,
        text: lines,
        html,
      });
      db.prepare("UPDATE email_notifications SET status='sent',error='',sent_at=CURRENT_TIMESTAMP WHERE id=?").run(row.lastInsertRowid);
      results.push({ recipient, sent: true, notificationId: row.lastInsertRowid });
    } catch (error) {
      const safeError = String(error?.message || "SMTP send failed").slice(0, 500);
      db.prepare("UPDATE email_notifications SET status='failed',error=? WHERE id=?").run(safeError, row.lastInsertRowid);
      console.error("Order email failed:", safeError);
      results.push({ recipient, sent: false, notificationId: row.lastInsertRowid, reason: "send_failed" });
    }
  }
  return {
    sent: results.length > 0 && results.every((result) => result.sent),
    customerSent: results.some((result) => result.recipient.toLowerCase() === order.account_email.toLowerCase() && result.sent),
    results,
  };
}

export async function verifyMailConfiguration() {
  const config = mailConfiguration();
  if (!config.configured) return { ok: false, error: "Заполните MAIL_USER и MAIL_APP_PASSWORD в .env." };
  try {
    await getTransport(config).verify();
    return { ok: true };
  } catch (error) {
    return { ok: false, error: String(error?.message || "SMTP connection failed").slice(0, 300) };
  }
}

export async function sendTestEmail() {
  const config = mailConfiguration();
  if (!config.configured) return { sent: false, error: "Заполните MAIL_USER и MAIL_APP_PASSWORD в .env." };
  try {
    await getTransport(config).sendMail({
      from: process.env.MAIL_FROM || `Form Store <${config.user}>`,
      to: config.recipient,
      subject: "Проверка уведомлений Form Store",
      text: "Почтовые уведомления магазина настроены. Новые заказы, отмены и изменения статусов будут приходить сюда.",
      html: "<p>Почтовые уведомления магазина настроены. Новые заказы, отмены и изменения статусов будут приходить сюда.</p>",
    });
    return { sent: true };
  } catch (error) {
    const safeError = String(error?.message || "SMTP send failed").slice(0, 300);
    console.error("Test email failed:", safeError);
    return { sent: false, error: safeError };
  }
}
