import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import seedProducts from "../shared/catalog.json" with { type: "json" };

const here = path.dirname(fileURLToPath(import.meta.url));
const dbPath = process.env.DATABASE_FILE
  ? path.resolve(process.cwd(), process.env.DATABASE_FILE)
  : path.join(here, "data", "store.sqlite");
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

export const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_hash TEXT,
    provider TEXT NOT NULL DEFAULT 'local',
    provider_id TEXT,
    role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','admin')),
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE UNIQUE INDEX IF NOT EXISTS users_provider_identity
    ON users(provider, provider_id) WHERE provider_id IS NOT NULL;
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    subtitle TEXT NOT NULL DEFAULT '',
    brand TEXT NOT NULL DEFAULT '',
    price INTEGER NOT NULL CHECK (price >= 0),
    badge TEXT NOT NULL DEFAULT '',
    image TEXT NOT NULL DEFAULT '',
    tags_json TEXT NOT NULL DEFAULT '[]',
    description TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL DEFAULT '',
    fresh INTEGER NOT NULL DEFAULT 0,
    specs_json TEXT NOT NULL DEFAULT '[]',
    in_the_box TEXT NOT NULL DEFAULT '',
    warranty TEXT NOT NULL DEFAULT '',
    delivery TEXT NOT NULL DEFAULT '',
    stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    status TEXT NOT NULL DEFAULT 'Оплачено (демо)',
    total INTEGER NOT NULL,
    subtotal INTEGER NOT NULL,
    discount INTEGER NOT NULL DEFAULT 0,
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL DEFAULT '',
    city TEXT NOT NULL DEFAULT '',
    address TEXT NOT NULL DEFAULT '',
    payment_label TEXT NOT NULL DEFAULT 'Демо-заказ, без реального списания',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    canceled_at TEXT
  );
  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    name_snapshot TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS stock_movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER REFERENCES products(id),
    product_name TEXT NOT NULL,
    kind TEXT NOT NULL,
    delta INTEGER NOT NULL,
    balance INTEGER NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS email_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT NOT NULL,
    event TEXT NOT NULL,
    recipient TEXT NOT NULL,
    subject TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    error TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    sent_at TEXT
  );
  CREATE TABLE IF NOT EXISTS oauth_states (
    state TEXT PRIMARY KEY,
    provider TEXT NOT NULL,
    nonce TEXT NOT NULL,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions (
    sid TEXT PRIMARY KEY,
    session_json TEXT NOT NULL,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS orders_user_id ON orders(user_id);
  CREATE INDEX IF NOT EXISTS movements_created_at ON stock_movements(created_at);
`);

const insertProduct = db.prepare(`
  INSERT INTO products
  (id,name,category,subtitle,brand,price,badge,image,tags_json,description,source,fresh,specs_json,in_the_box,warranty,delivery,stock)
  VALUES (@id,@name,@category,@subtitle,@brand,@price,@badge,@image,@tags_json,@description,@source,@fresh,@specs_json,@in_the_box,@warranty,@delivery,@stock)
  ON CONFLICT(id) DO UPDATE SET
    name=excluded.name, category=excluded.category, subtitle=excluded.subtitle,
    brand=excluded.brand, price=excluded.price, badge=excluded.badge, image=excluded.image,
    tags_json=excluded.tags_json, description=excluded.description, source=excluded.source,
    fresh=excluded.fresh, specs_json=excluded.specs_json, in_the_box=excluded.in_the_box,
    warranty=excluded.warranty, delivery=excluded.delivery
`);
const catalogVersion = db.prepare("SELECT value FROM app_meta WHERE key = 'catalog_version'").get()?.value;
if (catalogVersion !== "gaming-gear-2026-10-24c") {
  const applyCatalog = db.transaction(() => {
    for (const product of seedProducts) {
      const existing = db.prepare("SELECT id,stock FROM products WHERE id = ?").get(product.id);
      const stock = existing?.stock ?? (product.category === "laptop" ? 4 : product.category === "mousepad" ? 12 : 6);
      insertProduct.run({
        id: product.id,
        name: product.name,
        category: product.category,
        subtitle: product.subtitle || "",
        brand: product.brand || "",
        price: product.price,
        badge: product.badge || "",
        image: product.image || "",
        tags_json: JSON.stringify(product.tags || []),
        description: product.description || "",
        source: product.source || "",
        fresh: product.fresh ? 1 : 0,
        specs_json: JSON.stringify(product.specs || []),
        in_the_box: product.inTheBox || "",
        warranty: product.warranty || "",
        delivery: product.delivery || "",
        stock
      });
      db.prepare("UPDATE products SET active = 1 WHERE id = ?").run(product.id);
    }
    const activeIds = seedProducts.map((product) => product.id);
    const placeholders = activeIds.map(() => "?").join(",");
    db.prepare(`UPDATE products SET active = 0 WHERE id BETWEEN 1 AND 100 AND id NOT IN (${placeholders})`).run(...activeIds);
    db.prepare("INSERT INTO app_meta (key,value) VALUES ('catalog_version','gaming-gear-2026-10-24c') ON CONFLICT(key) DO UPDATE SET value=excluded.value").run();
  });
  applyCatalog();
}
if (db.prepare("SELECT COUNT(*) AS count FROM stock_movements").get().count === 0) {
  const recordOpeningStock = db.prepare("INSERT INTO stock_movements (product_id,product_name,kind,delta,balance,note) VALUES (?,?,?,?,?,?)");
  const products = db.prepare("SELECT id,name,stock FROM products ORDER BY id").all();
  const writeOpeningStock = db.transaction(() => {
    for (const product of products) {
      recordOpeningStock.run(product.id, product.name, "Начальный остаток", product.stock, product.stock, "Первичная загрузка локального каталога");
    }
  });
  writeOpeningStock();
}

const adminEmail = (process.env.ADMIN_EMAIL || "admin@form.local").trim().toLowerCase();
const adminPassword = process.env.ADMIN_PASSWORD || "form2026";
if (!db.prepare("SELECT id FROM users WHERE email = ?").get(adminEmail)) {
  db.prepare("INSERT INTO users (name,email,password_hash,provider,role) VALUES (?,?,?,'local','admin')")
    .run("Администратор", adminEmail, bcrypt.hashSync(adminPassword, 12));
}

export function productFromRow(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    subtitle: row.subtitle,
    brand: row.brand,
    price: row.price,
    badge: row.badge,
    image: row.image,
    tags: JSON.parse(row.tags_json || "[]"),
    description: row.description,
    source: row.source,
    fresh: Boolean(row.fresh),
    specs: JSON.parse(row.specs_json || "[]"),
    inTheBox: row.in_the_box,
    warranty: row.warranty,
    delivery: row.delivery,
    stock: row.stock
  };
}

export function publicUser(row) {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    provider: row.provider,
    role: row.role,
    createdAt: row.created_at
  };
}
