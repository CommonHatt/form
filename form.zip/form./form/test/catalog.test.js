import test from "node:test";
import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import products from "../shared/catalog.json" with { type: "json" };

test("catalog contains distinct products with bundled product photography", () => {
  assert.equal(products.length, 30);
  assert.equal(new Set(products.map((item) => item.id)).size, 30);
  assert.equal(new Set(products.map((item) => item.name)).size, 30);
  assert.equal(new Set(products.map((item) => item.image)).size, 30);
  const projectDir = resolve(fileURLToPath(new URL("..", import.meta.url)));
  assert.ok(products.every((item) => item.image.startsWith("/products/")));
  assert.ok(products.every((item) => existsSync(resolve(projectDir, "public", item.image.slice(1)))));
  assert.ok(products.every((item) => item.source.startsWith("https://")));
  assert.ok(products.every((item) => Number.isInteger(item.price) && item.price > 0));
  const names = products.map((item) => item.name);
  for (const requested of ["ZOWIE XL2586X+", "ZOWIE XL2566X+", "Logitech PRO X2 SUPERSTRIKE", "Logitech G PRO X SUPERLIGHT 2", "Logitech PRO X TKL RAPID", "ASUS Zenbook S 16", "ASUS Zenbook S 14"]) {
    assert.ok(names.includes(requested), `missing ${requested}`);
  }
  for (const requested of ["MacBook Pro 16″ M4 Pro", "MacBook Pro 14″ M4 Pro", "Microsoft Surface Laptop 7 15″", "AMD Ryzen 7 7800X3D", "NVIDIA GeForce RTX 5080 Founders Edition", "Samsung 990 PRO 2 ТБ"]) {
    assert.ok(names.includes(requested), `missing ${requested}`);
  }
});

test("catalog covers requested esports categories", () => {
  assert.deepEqual([...new Set(products.map((item) => item.category))].sort(), ["component", "headphones", "keyboard", "laptop", "monitor", "mouse", "mousepad"]);
});

test("the complementary gaming set has one product from each matching category", () => {
  const byId = new Map(products.map((item) => [item.id, item]));
  const set = [1, 3, 5, 6, 20].map((id) => byId.get(id));
  assert.deepEqual(set.map((item) => item.category), ["monitor", "mouse", "keyboard", "mousepad", "headphones"]);
});
